package university.domain;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@Table(name = "lessons")
public class Lesson {
    @Id
    @GeneratedValue(generator = "seq_lesson", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "seq_lesson", sequenceName = "seq_lesson")
    @Column(name = "lesson_id")
    private int id;

    @Column(name = "lesson_datetime")
    private String day;

    @Column(name = "subject_name")
    private String subject;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "lessons_students", joinColumns = {
            @JoinColumn(name = "lesson_id", nullable = false, updatable = false) }, inverseJoinColumns = {
                    @JoinColumn(name = "student_id", nullable = false, updatable = false) })
    private List<Student> students;

    @JoinColumn(name = "teacher_id")
    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private Teacher teacher;

    @Column(name = "room")
    private String room;

    public Lesson() {
    }

    public Lesson(String day, String subject, List<Student> students, Teacher teacher, String room) {
        this.day = day;
        this.subject = subject;
        this.students = students;
        this.teacher = teacher;
        this.room = room;
    }

    public int getId() {
        return id;
    }

    public void setId(int lessonID) {
        this.id = lessonID;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public int getTeacherID() {
        return getTeacher().getId();
    }

    public String getTeacherFirstName() {
        return getTeacher().getFirstName();
    }

    public String getTeacherLastName() {
        return getTeacher().getLastName();
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    @Override
    public String toString() {
        return "Lesson [lessonID=" + id + ", day=" + day + ", subject=" + subject + ", students=" + students
                + ", teacher=" + ", room=" + room + "]";
    }

}
