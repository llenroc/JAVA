package university.dao.persistence;

import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import university.dao.utility.ConnectionFactory;
import university.domain.Student;

public class StudentDAO {

    private static final String SELECT_ALL_STATEMENT = "select student_id, first_name, last_name from Students";
    private static final String SELECT_BY_BUSINESS_KEY_STATEMENT = "select student_id, first_name, last_name from Students where first_name=:v_firstName and last_name=:v_lastName";
    private static final String SELECT_BY_STUDENTID_STATEMENT = "select student_id, first_name, last_name from Students where student_id=:v_student_id";
    private static final String COUNT_BY_BUSINESS_KEY_STATEMENT = "select count(*) from Students where firstName=:v_firstName and lastName=:v_lastName";

    private static final String FIRST_NAME_COLUMN_LABEL = "v_firstName";
    private static final String LAST_NAME_COLUMN_LABEL = "v_lastName";
    private static final String ID_COLUMN_LABEL = "v_student_id";

    private static final Logger log = LogManager.getLogger(StudentDAO.class);

    public void insert(Student student) {
        log.debug("Attempt to add new student: {}", student);
        if (!checkIfExists(student)) {
            log.debug("Creating new student: {}", student);
            ConnectionFactory connectionFactory = new ConnectionFactory();
            Session session = connectionFactory.getConnection().openSession();
            session.beginTransaction();
            session.save(student);
            session.getTransaction().commit();
            session.close();
            log.debug("Student created: {}", student);
        }
    }

    public void update(Student student) {
        log.debug("Attempt to update student: {}", student);
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        session.beginTransaction();
        session.update(student);
        session.getTransaction().commit();
        session.close();
        log.debug("Student updated");

    }

    public void delete(Student student) {
        log.debug("Attempt to delete student: {}", student);
        Student studentAttemptDelete = findByBusinessKey(student.getFirstName(), student.getLastName());
        if (studentAttemptDelete != null) {
            ConnectionFactory connectionFactory = new ConnectionFactory();
            Session session = connectionFactory.getConnection().openSession();
            session.beginTransaction();
            session.delete(studentAttemptDelete);
            session.getTransaction().commit();
            session.close();
            log.debug("Student deleted: {}", student);
        }
    }

    public List<Student> findAll() {
        log.debug("Retrieve all students");
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(SELECT_ALL_STATEMENT);
        query.addEntity(Student.class);
        log.debug("SQL statement: {}", query);
        List<Student> studentList = query.list();
        session.close();
        log.debug("Retrieved student: {}", studentList);
        return studentList;
    }

    public Student findByBusinessKey(String firstName, String lastName) {
        log.debug("Check if exists student by BK: firstName: {}; lastName: {}", firstName, lastName);
        Student studentOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(SELECT_BY_BUSINESS_KEY_STATEMENT);
        query.setParameter(FIRST_NAME_COLUMN_LABEL, firstName);
        query.setParameter(LAST_NAME_COLUMN_LABEL, lastName);
        query.addEntity(Student.class);
        log.debug("SQL statement: {}", query);
        List<Student> studentList = query.list();
        if (!studentList.isEmpty()) {
            studentOut = studentList.get(0);
        }
        session.close();
        log.debug("Student exists in database: {}", studentOut);
        return studentOut;
    }

    public Student findById(int student_id) {
        log.debug("Check if exists student with ID: {}", student_id);
        Student studentOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(SELECT_BY_STUDENTID_STATEMENT);
        query.setParameter(ID_COLUMN_LABEL, student_id);
        query.addEntity(Student.class);
        log.debug("SQL statement: {}", query);
        List<Student> studentList = query.list();
        if (!studentList.isEmpty()) {
            studentOut = studentList.get(0);
        }
        session.close();
        log.debug("Student exists in database: {}", studentOut);
        return studentOut;
    }

    public boolean checkIfExists(Student student) {
        log.debug("Check if exists student: {}", student);
        boolean result = false;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        Query query = session.createQuery(COUNT_BY_BUSINESS_KEY_STATEMENT);
        query.setParameter(FIRST_NAME_COLUMN_LABEL, student.getFirstName());
        query.setParameter(LAST_NAME_COLUMN_LABEL, student.getLastName());
        log.debug("SQL statement: {}", query);
        Iterator<Long> iterator = query.iterate();
        int countRows = Math.toIntExact(iterator.next());
        session.close();
        if (countRows != 0) {
            result = true;
            log.debug("Student exists in database: {}", student);
        }
        return result;
    }

}
