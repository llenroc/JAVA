package university.dao.persistence;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import university.dao.utility.ConnectionFactory;
import university.domain.Lesson;
import university.domain.Student;
import university.domain.Teacher;

public class LessonDAO {
    private static final String SELECT_FIND_BY_BUSINESS_KEY_STATEMENT = "select l.lesson_id, l.lesson_datetime, l.subject_name, l.teacher_id, l.room from lessons l inner join teachers t on l.teacher_id=t.teacher_id where subject_name=:v_subject_name and lesson_datetime=:v_lesson_datetime and t.first_name=:v_teacher_first_name and t.last_name=:v_teacher_last_name";
    private static final String LESSON_FIND_BY_LESSONID_STATEMENT = "select lesson_id, lesson_datetime, subject_name, teacher_id, room from Lessons where lesson_id=:v_lesson_id";
    private static final String LESSON_FIND_BY_TEACHERID_DAY_STATEMENT = "select lesson_id, lesson_datetime, subject_name, teacher_id, room from Lessons where teacher_id=:v_teacher_id and SUBSTRING(lesson_datetime,1,10)=:v_lesson_datetime";

    private static final String LESSONSTUDENT_FIND_BY_STUDENTID_STATEMENT = "select l.lesson_id, l.lesson_datetime, l.subject_name, l.teacher_id, l.room from Lessons l inner join lessons_students s on l.lesson_id=s.lesson_id where SUBSTRING(l.lesson_datetime,1,10)=:v_lesson_datetime and student_id=:v_student_id";
    private static final String LESSONSTUDENT_ALL_STATEMENT = "select l.lesson_id, l.lesson_datetime, l.subject_name, l.teacher_id, l.room from Lessons l";
    private static final String LESSONSTUDENT_FIND_BY_LESSONID_STATEMENT = "select s.student_id, s.first_name, s.last_name from lessons_students l inner join students s on l.student_id=s.student_id where l.lesson_id=:v_lesson_id";

    private static final String LESSON_ID_COLUMN_LABEL = "v_lesson_id";
    private static final String DATETIME_COLUMN_LABEL = "v_lesson_datetime";
    private static final String SUBJECT_NAME_COLUMN_LABEL = "v_subject_name";
    private static final String TEACHER_ID_COLUMN_LABEL = "v_teacher_id";
    private static final String TEACHER_FIRST_NAME_COLUMN_LABEL = "v_teacher_first_name";
    private static final String TEACHER_LAST_NAME_COLUMN_LABEL = "v_teacher_last_name";
    private static final String STUDENT_ID_COLUMN_LABEL = "v_student_id";

    private static final Logger log = LogManager.getLogger(LessonDAO.class);

    public void insert(Lesson lesson) {
        log.debug("Attempt to add new lesson: {}", lesson);
        if (!checkIfExists(lesson)) {
            log.debug("Creating new lesson: {}", lesson);
            ConnectionFactory connectionFactory = new ConnectionFactory();
            Session session = connectionFactory.getConnection().openSession();
            session.beginTransaction();
            session.save(lesson);
            session.getTransaction().commit();
            session.close();
        }
        log.debug("Lesson created: {}", lesson);
    }

    public void update(Lesson lesson) {
        log.debug("Attempt to update lesson: {}", lesson);
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        session.beginTransaction();
        session.update(lesson);
        session.getTransaction().commit();
        session.close();
        log.debug("Lesson after updated");
    }

    public void delete(Lesson lesson) {
        log.debug("Attempt to delete lesson: {}", lesson);
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Lesson lessonAttemptDelete = findByBusinessKey(lesson);
        if (lessonAttemptDelete != null) {
            Session session = connectionFactory.getConnection().openSession();
            session.beginTransaction();
            session.delete(lessonAttemptDelete);
            session.getTransaction().commit();
            session.close();
            log.debug("Lesson deleted: {}", lesson);
        }
    }

    public List<Lesson> findAll() {
        log.debug("Retrieve all lessons");
        List<Lesson> lessonListOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(LESSONSTUDENT_ALL_STATEMENT);
        query.addEntity(Lesson.class);
        log.debug("SQL statement: {}", query);
        lessonListOut = query.list();
        session.close();
        log.debug("Lesson exists in database: {}", lessonListOut);
        return lessonListOut;
    }

    public List<Lesson> findByStudentAndDay(LocalDateTime dateOfLesson, Student student) {
        log.debug("Retrieve lessons by student and day");
        String dayOfLesson = dateOfLesson.toString().substring(0, 10);
        StudentDAO studentDAO = new StudentDAO();
        int student_id = studentDAO.findByBusinessKey(student.getFirstName(), student.getLastName()).getId();
        List<Lesson> lessonListOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(LESSONSTUDENT_FIND_BY_STUDENTID_STATEMENT);
        query.setParameter(STUDENT_ID_COLUMN_LABEL, student_id);
        query.setParameter(DATETIME_COLUMN_LABEL, dayOfLesson);
        query.addEntity(Lesson.class);
        log.debug("SQL statement: {}", query);
        lessonListOut = query.list();
        session.close();
        log.debug("Lesson exists in database: {}", lessonListOut);
        return lessonListOut;
    }

    public List<Lesson> findByTeacherAndDay(LocalDateTime dateOfLesson, Teacher teacher) {
        log.debug("Retrieve lessons by teacher and day");
        String dayOfLesson = dateOfLesson.toString().substring(0, 10);
        TeacherDAO teacherDAO = new TeacherDAO();
        int teacher_id = teacherDAO.findByBusinessKey(teacher.getFirstName(), teacher.getLastName()).getId();
        List<Lesson> lessonListOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(LESSON_FIND_BY_TEACHERID_DAY_STATEMENT);
        query.setParameter(TEACHER_ID_COLUMN_LABEL, teacher_id);
        query.setParameter(DATETIME_COLUMN_LABEL, dayOfLesson);
        query.addEntity(Lesson.class);
        log.debug("SQL statement: {}", query);
        lessonListOut = query.list();
        session.close();
        log.debug("Lesson exists in database: {}", lessonListOut);
        return lessonListOut;
    }

    public Lesson findById(int lesson_id) {
        log.debug("Check if Lesson exists with ID: {}", lesson_id);
        Lesson lessonOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(LESSON_FIND_BY_LESSONID_STATEMENT);
        query.setParameter(LESSON_ID_COLUMN_LABEL, lesson_id);
        query.addEntity(Lesson.class);
        log.debug("SQL statement: {}", query);
        List<Lesson> studentList = query.list();
        if (!studentList.isEmpty()) {
            lessonOut = studentList.get(0);
        }
        session.close();
        log.debug("Lesson exists in database: {}", lessonOut);
        return lessonOut;
    }

    public List<Student> getStudentsById(int lesson_id) {
        log.debug("Get students for lesson with ID: {}", lesson_id);
        List<Student> studentListOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(LESSONSTUDENT_FIND_BY_LESSONID_STATEMENT);
        query.setParameter(LESSON_ID_COLUMN_LABEL, lesson_id);
        query.addEntity(Student.class);
        log.debug("SQL statement: {}", query);
        studentListOut = query.list();
        session.close();
        return studentListOut;
    }

    public Lesson findByBusinessKey(Lesson lesson) {
        log.debug("Check if Lesson exists by business key: {}");
        Lesson lessonOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(SELECT_FIND_BY_BUSINESS_KEY_STATEMENT);
        query.setParameter(SUBJECT_NAME_COLUMN_LABEL, lesson.getSubject());
        query.setParameter(DATETIME_COLUMN_LABEL, lesson.getDay());
        query.setParameter(TEACHER_FIRST_NAME_COLUMN_LABEL, lesson.getTeacher().getFirstName());
        query.setParameter(TEACHER_LAST_NAME_COLUMN_LABEL, lesson.getTeacher().getLastName());
        query.addEntity(Lesson.class);
        log.debug("SQL statement: {}", query);
        List<Lesson> studentList = query.list();
        if (!studentList.isEmpty()) {
            lessonOut = studentList.get(0);
        }
        session.close();
        log.debug("Lesson exists in database: {}", lessonOut);
        return lessonOut;
    }

    public boolean checkIfExists(Lesson lesson) {
        log.debug("Check if lesson exists: {}", lesson);
        boolean result = false;
        if (findByBusinessKey(lesson) != null) {
            result = true;
            log.debug("Lesson exists in database: {}", lesson);
        }
        return result;
    }

}
