package university.test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.runners.MockitoJUnitRunner;

import university.dao.persistence.LessonDAO;
import university.dao.persistence.StudentDAO;
import university.dao.persistence.TeacherDAO;
import university.domain.Lesson;
import university.domain.Student;
import university.domain.Teacher;

@RunWith(MockitoJUnitRunner.class)
public class LessonDAOTest {

    private LessonDAO lessonDAO = new LessonDAO();

    @Mock
    private TeacherDAO teacherDAO;

    @Mock
    private StudentDAO studentDAO;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Test
    public void testCheckIfExists() throws Exception {
        List<Student> students1 = new ArrayList<Student>();
        students1.add(new Student("Ivan", "Borisav"));
        students1.add(new Student("John", "Maclein"));
        students1.add(new Student("Alex", "Dimitrov"));
        Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
        LocalDate localDate1 = LocalDate.of(2019, 2, 5);
        LocalTime localTime1 = LocalTime.of(8, 00);
        String day1 = String.valueOf(LocalDateTime.of(localDate1, localTime1));
        Lesson testLesson1 = new Lesson(day1, "Mathematical Analysis", students1, teacher1, "346");
        boolean testBoolean = true;

        Mockito.when(lessonDAO.checkIfExists(testLesson1)).thenReturn(testBoolean);
        boolean actualBoolean = lessonDAO.checkIfExists(testLesson1);

        Assert.assertEquals(testBoolean, actualBoolean);

    }

    @Test
    public void testFindAll() throws Exception {
        List<Student> studentsList = new ArrayList<Student>();
        Student student1 = new Student("Ivan", "Borisav");
        Student student2 = new Student("Ivan", "Borisav");
        Student student3 = new Student("Ivan", "Borisav");
        studentsList.add(student1);
        studentsList.add(student2);
        studentsList.add(student3);
        Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
        Teacher teacher2 = new Teacher("Oleg", "Klyosov");
        Teacher teacher3 = new Teacher("Vera", "Virchenko");
        LocalDate localDate1 = LocalDate.of(2019, 2, 5);
        LocalTime localTime1 = LocalTime.of(8, 00);
        LocalTime localTime2 = LocalTime.of(9, 00);
        LocalTime localTime3 = LocalTime.of(10, 00);
        String day1 = String.valueOf(LocalDateTime.of(localDate1, localTime1));
        String day2 = String.valueOf(LocalDateTime.of(localDate1, localTime2));
        String day3 = String.valueOf(LocalDateTime.of(localDate1, localTime3));
        Lesson lesson1 = new Lesson(day1, "Mathematical Analysis", studentsList, teacher1, "346");
        Lesson lesson2 = new Lesson(day2, "Hydromechanics", studentsList, teacher2, "400");
        Lesson lesson3 = new Lesson(day3, "Discrete Mathematics", studentsList, teacher3, "102");
        List<Lesson> testLessonsList = new ArrayList<>();
        testLessonsList.add(lesson1);
        testLessonsList.add(lesson2);
        testLessonsList.add(lesson3);

        Mockito.when(lessonDAO.findAll()).thenReturn(testLessonsList);
        List<Lesson> actualLessonsList = lessonDAO.findAll();

        for (int j = 0; j < testLessonsList.size(); j++) {
            Assert.assertEquals(testLessonsList.get(j).getDay(), actualLessonsList.get(j).getDay());
            Assert.assertEquals(testLessonsList.get(j).getSubject(), actualLessonsList.get(j).getSubject());
            Assert.assertEquals(testLessonsList.get(j).getStudents(), actualLessonsList.get(j).getStudents());
            Assert.assertEquals(testLessonsList.get(j).getTeacher(), actualLessonsList.get(j).getTeacher());
            Assert.assertEquals(testLessonsList.get(j).getRoom(), actualLessonsList.get(j).getRoom());
        }
    }
}
