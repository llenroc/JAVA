package university.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import university.dao.persistence.DAOException;
import university.dao.persistence.StudentDAO;
import university.domain.Lesson;
import university.domain.Student;
import university.domain.Teacher;
import university.domain.University;

@WebServlet("/")
public class UniversityServlet extends HttpServlet {
    private static final String JSP_PAGE_HOME = "main_form.jsp";
    private static final String JSP_PAGE_EDIT_SCHEDULE = "edit_schedule_form.jsp";
    private static final String JSP_PAGE_DELETE_SCHEDULE = "delete_schedule_form.jsp";
    private static final String JSP_LESSON_ID_COLUMN_LABEL = "lessonID";
    private static final String JSP_DATETIME_COLUMN_LABEL = "day";
    private static final String JSP_SUBJECT_NAME_COLUMN_LABEL = "subject";
    private static final String JSP_ROOM_COLUMN_LABEL = "room";
    private static final String JSP_STUDENT_FIRST_NAME_COLUMN_LABEL = "studentFirstName";
    private static final String JSP_STUDENT_LAST_NAME_COLUMN_LABEL = "studentLastName";
    private static final String JSP_TEACHER_FIRST_NAME_COLUMN_LABEL = "teacherFirstName";
    private static final String JSP_TEACHER_LAST_NAME_COLUMN_LABEL = "teacherLastName";
    private static final long serialVersionUID = 1L;
    private static final Logger log = LogManager.getLogger(StudentDAO.class);
    private University university = new University();
    private List<Lesson> scheduleOfAllPeriod;
    private RequestDispatcher dispatcher;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        log.debug("Start of processing request: {}", request);
        String action = request.getServletPath();
        switch (action) {
        case "/showScheduleAddForm":
            showScheduleAddForm(request, response);
            break;
        case "/showScheduleEditForm":
            showScheduleEditForm(request, response);
            break;
        case "/showScheduleDeleteForm":
            showScheduleDeleteForm(request, response);
            break;
        case "/deleteSchedule":
            doDelete(request, response);
            break;
        default:
            listAllSchedule(request, response);
            break;
        }
        log.debug("Finish of processing request: {}", request);
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        deleteSchedule(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        addSchedule(request, response);
        String action = request.getServletPath();
        switch (action) {
        case "/addSchedule":
            addSchedule(request, response);
            break;
        case "/updateSchedule":
            updateSchedule(request, response);
            break;
        }
    }

    private void listAllSchedule(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        log.debug("Start of method [listAllSchedule]: {}", request);
        try {
            scheduleOfAllPeriod = university.getScheduleAll();
            request.setAttribute("scheduleOfAllPeriod", scheduleOfAllPeriod);
            dispatcher = request.getRequestDispatcher(JSP_PAGE_HOME);
            dispatcher.forward(request, response);
        } catch (Exception e) {
            throw new DAOException("Error of sending all lessons to jsp: " + e.getMessage());
        }
        log.debug("Finish of method  [listAllSchedule]: {}", request);
    }

    private void showScheduleAddForm(HttpServletRequest request, HttpServletResponse response) {
        try {
            log.debug("Start of method [showScheduleAddForm]: {}", request);
            dispatcher = request.getRequestDispatcher(JSP_PAGE_EDIT_SCHEDULE);
            dispatcher.forward(request, response);
        } catch (IOException | ServletException e) {
            throw new DAOException("Error in method [showScheduleAddForm]:" + e.getMessage());
        }
        log.debug("Finish of method  [showScheduleAddForm]: {}", request);
    }

    private void showScheduleEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            log.debug("Start of method [showScheduleEditForm]: {}", request);
            int id = Integer.parseInt(request.getParameter(JSP_LESSON_ID_COLUMN_LABEL));
            Lesson lesson = university.getScheduleByID(id);

            dispatcher = request.getRequestDispatcher(JSP_PAGE_EDIT_SCHEDULE);
            request.setAttribute("lesson", lesson);
            dispatcher.forward(request, response);
        } catch (Exception e) {
            throw new DAOException("Error of opening the jsp page showScheduleEditForm: " + e.getMessage());
        }
        log.debug("Finish of method  [showScheduleEditForm]: {}", request);
    }

    private void showScheduleDeleteForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            log.debug("Start of method [showScheduleDeleteForm]: {}", request);
            int id = Integer.parseInt(request.getParameter(JSP_LESSON_ID_COLUMN_LABEL));
            Lesson lesson = university.getScheduleByID(id);

            dispatcher = request.getRequestDispatcher(JSP_PAGE_DELETE_SCHEDULE);
            request.setAttribute("lesson", lesson);
            dispatcher.forward(request, response);
        } catch (Exception e) {
            throw new DAOException("Error of opening the jsp page showScheduleDeleteForm: " + e.getMessage());
        }
        log.debug("Finish of method  [showScheduleDeleteForm]: {}", request);
    }

    private void addSchedule(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            log.debug("Start of method [addSchedule]: {}", request);
            String day = request.getParameter(JSP_DATETIME_COLUMN_LABEL);
            String subject = request.getParameter(JSP_SUBJECT_NAME_COLUMN_LABEL);
            String room = request.getParameter(JSP_ROOM_COLUMN_LABEL);
            String studentFirstName = request.getParameter(JSP_STUDENT_FIRST_NAME_COLUMN_LABEL);
            String studentLastName = request.getParameter(JSP_STUDENT_LAST_NAME_COLUMN_LABEL);
            String teacherFirstName = request.getParameter(JSP_TEACHER_FIRST_NAME_COLUMN_LABEL);
            String teacherLastName = request.getParameter(JSP_TEACHER_LAST_NAME_COLUMN_LABEL);

            Student student = new Student(studentFirstName, studentLastName);
            university.enrollStudent(student);
            List<Student> studentsGroup = new ArrayList<Student>();
            studentsGroup.add(student);

            Teacher teacher = new Teacher(teacherFirstName, teacherLastName);
            university.hireTeacher(teacher);

            Lesson lesson = new Lesson(day, subject, studentsGroup, teacher, room);
            university.addSchedule(lesson);
            listAllSchedule(request, response);
        } catch (Exception e) {
            throw new DAOException("Error of adding new schedule: " + e.getMessage());
        }
        log.debug("Finish of method  [addSchedule]: {}", request);
    }

    private void updateSchedule(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            log.debug("Start of method [updateSchedule]: {}", request);
            int lessonID = Integer.parseInt(request.getParameter(JSP_LESSON_ID_COLUMN_LABEL));
            String day = request.getParameter(JSP_DATETIME_COLUMN_LABEL);
            String subject = request.getParameter(JSP_SUBJECT_NAME_COLUMN_LABEL);
            String room = request.getParameter(JSP_ROOM_COLUMN_LABEL);

            Lesson lesson = university.getScheduleByID(lessonID);            
            lesson.setDay(day);
            lesson.setSubject(subject);
            lesson.setRoom(room);
            university.updateSchedule(lesson);
            listAllSchedule(request, response);
        } catch (Exception e) {
            throw new DAOException("Error of updateing schedule: " + e.getMessage());
        }
        log.debug("Finish of method  [updateSchedule]: {}", request);
    }

    private void deleteSchedule(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            log.debug("Start of method [deleteSchedule]: {}", request);
            int lessonID = Integer.parseInt(request.getParameter(JSP_LESSON_ID_COLUMN_LABEL));
            Lesson lesson = university.getScheduleByID(lessonID);
            university.deleteSchedule(lesson);
            listAllSchedule(request, response);
        } catch (Exception e) {
            throw new DAOException("Error of deleting new schedule: " + e.getMessage());
        }
        log.debug("Finish of method  [deleteSchedule]: {}", request);
    }
}
