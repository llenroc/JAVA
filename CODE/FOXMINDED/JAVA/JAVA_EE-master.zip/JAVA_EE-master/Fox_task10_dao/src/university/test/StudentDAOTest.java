package university.test;

import static org.mockito.Mockito.mock;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import university.dao.persistence.StudentDAO;
import university.domain.Student;

public class StudentDAOTest {

    private StudentDAO studentDao = mock(StudentDAO.class);

    @Test
    public void testFindByBusinessKey() throws Exception {
        Student testStudent1 = new Student("Ivan", "Borisav");
        Mockito.when(studentDao.findByBusinessKey(testStudent1.getFirstName(), testStudent1.getLastName()))
                .thenReturn(testStudent1);
        Student actualStudent1 = studentDao.findByBusinessKey(testStudent1.getFirstName(), testStudent1.getLastName());

        Assert.assertEquals(actualStudent1.getFirstName(), testStudent1.getFirstName());
        Assert.assertEquals(actualStudent1.getLastName(), testStudent1.getLastName());
    }

    @Test
    public void testStudentDAO_findAll() throws Exception {
        List<Student> testStudentsList = new ArrayList<Student>();
        testStudentsList.add(new Student("Ivan", "Borisav"));
        testStudentsList.add(new Student("John", "Maclein"));
        testStudentsList.add(new Student("Alex", "Dimitrov"));
        Mockito.when(studentDao.findAll()).thenReturn(testStudentsList);
        List<Student> actualStudentsList = studentDao.findAll();

        for (int j = 0; j < testStudentsList.size(); j++) {
            Assert.assertEquals(testStudentsList.get(j).getFirstName(), actualStudentsList.get(j).getFirstName());
            Assert.assertEquals(testStudentsList.get(j).getLastName(), actualStudentsList.get(j).getLastName());
        }
    }

}
