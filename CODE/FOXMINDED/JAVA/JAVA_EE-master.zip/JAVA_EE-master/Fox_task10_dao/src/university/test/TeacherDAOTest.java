package university.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import university.dao.persistence.TeacherDAO;
import university.domain.Teacher;

public class TeacherDAOTest {

    private TeacherDAO teacherDAO = new TeacherDAO();

    @Test
    public void testFindByBusinessKey() throws Exception {
        Teacher testTeacher1 = new Teacher("Valeryi", "Buldigin");
        Teacher actualStudent1 = teacherDAO.findByBusinessKey(testTeacher1.getFirstName(), testTeacher1.getLastName());

        Assert.assertEquals(testTeacher1.getFirstName(), actualStudent1.getFirstName());
        Assert.assertEquals(testTeacher1.getLastName(), actualStudent1.getLastName());
    }

    @Test
    public void testCheckIfExists() throws Exception {
        Teacher testTeacher1 = new Teacher("Valeryi", "Buldigin");
        boolean testBoolean = true;
        boolean actualBoolean = teacherDAO.checkIfExists(testTeacher1);

        Assert.assertEquals(testBoolean, actualBoolean);
    }

    @Test
    public void testFindAll() throws Exception {
        List<Teacher> testTeachersList = new ArrayList<>();
        testTeachersList.add(new Teacher("Valeryi", "Buldigin"));
        testTeachersList.add(new Teacher("Oleg", "Klyosov"));
        testTeachersList.add(new Teacher("Vera", "Virchenko"));
        testTeachersList.add(new Teacher("Petr", "Sshkabara"));
        testTeachersList.add(new Teacher("Nokolayi", "Petrenk"));
        testTeachersList.add(new Teacher("Sergei", "Saenko"));
        testTeachersList.add(new Teacher("Pavel", "Ageev"));
        testTeachersList.add(new Teacher("Denis", "Ryndin"));
        testTeachersList.add(new Teacher("Oleg", "Popov"));
        testTeachersList.add(new Teacher("Pavel", "Zalevskyi"));

        List<Teacher> actualStudentsList = teacherDAO.findAll();

        for (int j = 0; j < testTeachersList.size(); j++) {
            Assert.assertEquals(testTeachersList.get(j).getFirstName(), actualStudentsList.get(j).getFirstName());
            Assert.assertEquals(testTeachersList.get(j).getLastName(), actualStudentsList.get(j).getLastName());
        }
    }
}
