package university.dao.utility;

public class ConnectionCouldNotBeCreatedException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private String message;
    private Exception exception;

    public ConnectionCouldNotBeCreatedException(String message, Exception exception) {
        super();
        this.message = message;
        this.exception = exception;
        printStackTrace();
    }

    public String getMessage() {
        return message;
    }

    public Exception getException() {
        return exception;
    }
    
    public void printStackTrace()
    {
        exception.printStackTrace(); 
    }
}
