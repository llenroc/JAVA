package university.dao.persistence;


import java.sql.SQLException;

public class DAOException extends RuntimeException {
    private String message;
    private SQLException sqlException;

    public DAOException(SQLException sqlException) {
        this.sqlException = sqlException;
    }

    public DAOException(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public SQLException getSqlException() {
        return sqlException;
    }

}
