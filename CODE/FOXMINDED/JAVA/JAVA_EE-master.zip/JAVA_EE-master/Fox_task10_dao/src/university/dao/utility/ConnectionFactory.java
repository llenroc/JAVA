package university.dao.utility;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class ConnectionFactory {
    private static final Logger log = LogManager.getLogger(ConnectionFactory.class);
    private final SessionFactory sessionFactory;

    public ConnectionFactory() {
        sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
    }

    public SessionFactory getConnection() {
        try {
            SessionFactory connection = sessionFactory;
            log.debug("Connection established");
            return connection;
        } catch (Exception e) {
            throw new ConnectionCouldNotBeCreatedException("Session Factory could not be created:", e);
        }

    }
}