package university.domain;

import java.time.LocalDateTime;
import java.util.List;

import university.dao.persistence.LessonDAO;
import university.dao.persistence.StudentDAO;
import university.dao.persistence.TeacherDAO;

public class University {
    private StudentDAO studentDAO = new StudentDAO();
    private TeacherDAO teacherDAO = new TeacherDAO();
    private LessonDAO lessonDAO = new LessonDAO();

    public void enrollStudent(Student student) {
        studentDAO.insert(student);
    }

    public void excludeStudent(Student student) {
        studentDAO.delete(student);
    }

    public void hireTeacher(Teacher teacher) {
        teacherDAO.insert(teacher);
    }

    public void fireTeacher(Teacher teacher) {
        teacherDAO.delete(teacher);
    }

    public void addLesson(Lesson lesson) {

        lessonDAO.insert(lesson);
    }

    public void removeLesson(Lesson lesson) {
        lessonDAO.delete(lesson);
    }

    public List<Lesson> getScheduleByStudentAndDay(Student student, LocalDateTime inputDate) throws Exception {
        return lessonDAO.findByStudentAndDay(inputDate, student);

    }

    public List<Lesson> getScheduleByTeacherAndDay(Teacher teacher, LocalDateTime inputDate) throws Exception {
        return lessonDAO.findByTeacherAndDay(inputDate, teacher);
    }

    public Lesson getScheduleByID(int lessonId) throws Exception {
        return lessonDAO.findById(lessonId);
    }

    public List<Lesson> getScheduleAll() throws Exception {
        return lessonDAO.findAll();
    }

    public void addSchedule(Lesson lesson) throws Exception {
        lessonDAO.insert(lesson);
    }

    public void updateSchedule(Lesson lesson) throws Exception {
        lessonDAO.update(lesson);
    }

    public void deleteSchedule(Lesson lesson) throws Exception {
        lessonDAO.delete(lesson);
    }

}
