package university.dao.persistence;

import java.util.Iterator;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import university.dao.utility.ConnectionFactory;
import university.domain.Teacher;

public class TeacherDAO {
    private static final String SELECT_ALL_STATEMENT = "select teacher_id, first_name, last_name from Teachers";
    private static final String SELECT_BY_BUSINESS_KEY_STATEMENT = "select teacher_id, first_name, last_name from Teachers where first_name=:v_firstName and last_name=:v_lastName";
    private static final String SELECT_BY_TEACHERID_STATEMENT = "select teacher_id, first_name, last_name from Teachers where teacher_id=:v_teacher_id";
    private static final String COUNT_BY_BUSINESS_KEY_STATEMENT = "select count(*) from Teachers where firstName=:v_firstName and lastName=:v_lastName";

    private static final String FIRST_NAME_COLUMN_LABEL = "v_firstName";
    private static final String LAST_NAME_COLUMN_LABEL = "v_lastName";
    private static final String ID_COLUMN_LABEL = "v_teacher_id";

    private static final Logger log = LogManager.getLogger(TeacherDAO.class);

    public void insert(Teacher teacher) {
        log.debug("Attempt to add new teacher: {}", teacher);
        if (!checkIfExists(teacher)) {
            log.debug("Creating new teacher: {}", teacher);
            ConnectionFactory connectionFactory = new ConnectionFactory();
            Session session = connectionFactory.getConnection().openSession();
            session.beginTransaction();
            session.save(teacher);
            session.getTransaction().commit();
            session.close();
            log.debug("Teacher created: {}", teacher);
        }
    }

    public void update(Teacher teacher) {
        log.debug("Attempt to update teacher: {}", teacher);
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        session.beginTransaction();
        session.update(teacher);
        session.getTransaction().commit();
        session.close();
        log.debug("Teacher updated");

    }

    public void delete(Teacher teacher) {
        log.debug("Attempt to delete teacher: {}", teacher);
        Teacher teacherAttemptDelete = findByBusinessKey(teacher.getFirstName(), teacher.getLastName());
        if (teacherAttemptDelete != null) {
            ConnectionFactory connectionFactory = new ConnectionFactory();
            Session session = connectionFactory.getConnection().openSession();
            session.beginTransaction();
            session.delete(teacherAttemptDelete);
            session.getTransaction().commit();
            session.close();
            log.debug("Teacher deleted: {}", teacher);
        }
    }

    public List<Teacher> findAll() {
        log.debug("Retrieve all teachers");
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(SELECT_ALL_STATEMENT);
        query.addEntity(Teacher.class);
        log.debug("SQL statement: {}", query);
        List<Teacher> teacherList = query.list();
        session.close();
        log.debug("Retrieved teacher: {}", teacherList);
        return teacherList;
    }

    public Teacher findByBusinessKey(String firstName, String lastName) {
        log.debug("Check if exists teacher by BK: firstName: {}; lastName: {}" + firstName, lastName);
        Teacher teacherOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(SELECT_BY_BUSINESS_KEY_STATEMENT);
        query.setParameter(FIRST_NAME_COLUMN_LABEL, firstName);
        query.setParameter(LAST_NAME_COLUMN_LABEL, lastName);
        query.addEntity(Teacher.class);
        log.debug("SQL statement: {}", query);
        List<Teacher> teacherList = query.list();
        if (!teacherList.isEmpty()) {
            teacherOut = teacherList.get(0);
        }
        session.close();
        log.debug("Teacher exists in database: {}", teacherOut);
        return teacherOut;
    }

    public Teacher findById(int teacher_id) {
        log.debug("Check if exists teacher with ID: {}", teacher_id);
        Teacher teacherOut = null;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        SQLQuery query = session.createSQLQuery(SELECT_BY_TEACHERID_STATEMENT);
        query.setParameter(ID_COLUMN_LABEL, teacher_id);
        query.addEntity(Teacher.class);
        log.debug("SQL statement: {}", query);
        List<Teacher> teacherList = query.list();
        if (!teacherList.isEmpty()) {
            teacherOut = teacherList.get(0);
        }
        session.close();
        log.debug("Teacher exists in database: {}", teacherOut);
        return teacherOut;
    }

    public boolean checkIfExists(Teacher teacher) {
        log.debug("Check if exists teacher: {}", teacher);
        boolean result = false;
        ConnectionFactory connectionFactory = new ConnectionFactory();
        Session session = connectionFactory.getConnection().openSession();
        Query query = session.createQuery(COUNT_BY_BUSINESS_KEY_STATEMENT);
        query.setParameter("v_firstName", teacher.getFirstName());
        query.setParameter("v_lastName", teacher.getLastName());
        log.debug("SQL statement: {}", query);
        Iterator<Long> iterator = query.iterate();
        int countRows = Math.toIntExact(iterator.next());
        session.close();
        if (countRows != 0) {
            result = true;
            log.debug("Teacher exists in database: {}", teacher);
        }
        return result;
    }

}
