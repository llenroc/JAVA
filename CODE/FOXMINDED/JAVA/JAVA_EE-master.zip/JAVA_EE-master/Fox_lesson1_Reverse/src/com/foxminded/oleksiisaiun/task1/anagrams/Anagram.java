package com.foxminded.oleksiisaiun.task1.anagrams;

/**
 * Anagram - write an application that reverses all the words of input text
 *
 * @version 2.3 2018-Mar-04
 * @author Oleksii Saiun
 */
public class Anagram {

	public String getAnagram(String input) {
		String output = anagram(input);
		return output;
	}

	private String[] reverseSentence(String str) {
		String[] words = str.split(" ");
		String[] reverse = new String[words.length];

		for (int k = words.length - 1; k >= 0; k--) {
			reverse[k] = "";

			for (int i = words[k].length() - 1; i >= 0; i--) {
				if (Character.isAlphabetic(words[k].charAt(i))) {
					reverse[k] = reverse[k] + words[k].charAt(i);
				}
			}

		}
		return reverse;
	}

	private String anagram(String input) {
		String anagrams = "";

		if (input != null) {
			String[] words = input.split("\\s+");
			String[] reverse = reverseSentence(input);

			for (int i = 0; i < reverse.length; i++) {
				int index = 0;

				for (int j = 0; j < words[i].length(); j++) {
					if (Character.isAlphabetic(words[i].charAt(j))) {
						anagrams = anagrams + reverse[i].charAt(index);
						index++;
					} else {
						anagrams = anagrams + words[i].charAt(j);
					}
				}
				anagrams = anagrams + " ";
			}

			anagrams = anagrams.trim();
		} else {
			anagrams = null;
		}
		return anagrams;
	}

	public static void main(String args[]) {
		Anagram anagram = new Anagram();
		String input = "a1bc-d ab fg6hj ow1 1abc2"; // enter input

		System.out.println("Input:");
		System.out.println(input);
		System.out.println("Output:");
		System.out.println(anagram.getAnagram(input));

	}
}
