package com.foxminded.oleksiisaiun.task1.anagrams;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestAnagram {
	Anagram anagram = new Anagram();

	@Test
	public void testGetAnagram_OneWord() {
		String input = "abc*d";
		String check = "dcb*a";
		assertEquals(check, anagram.getAnagram(input));
	}

	@Test
	public void testGetAnagram_OneWordComplex() {
		String input = "]U_n_it-ed_KinG`dom..";
		String check = "]m_o_dG-ni_Kdet`inU..";
		assertEquals(check, anagram.getAnagram(input));
	}

	@Test
	public void testGetAnagram_TwoWords() {
		String input = "ole23g 1xyz2";
		String check = "gel23o 1zyx2";
		assertEquals(check, anagram.getAnagram(input));
	}

	@Test
	public void testGetAnagram_FiveWords() {
		String input = "Hi Worl3d* it^ &is my pro**gram*";
		String check = "iH dlro3W* ti^ &si ym mar**gorp*";
		assertEquals(check, anagram.getAnagram(input));
	}

	@Test
	public void testGetAnagram_Empty() {
		String input = "";
		String check = "";
		assertEquals(check, anagram.getAnagram(input));
	}

	@Test
	public void testGetAnagram_OnlyNumbers() {
		String input = "123 456 000 8765";
		String check = "123 456 000 8765";
		assertEquals(check, anagram.getAnagram(input));
	}

	@Test
	public void testGetAnagram_SpecSymbols() {
		String input = "*&@ ---- ******* / .";
		String check = "*&@ ---- ******* / .";
		assertEquals(check, anagram.getAnagram(input));
	}

	@Test
	public void testGetAnagram_Null() {
		String input = null;
		String check = null;
		assertNull(check, anagram.getAnagram(input));
	}
	
}
