package com.foxminded.oleksiisaiun.task5.collections;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Cache {

	public Map<String, Integer> count;
	private final int SIZE_CACHE = 4;
	private Map<String, Integer> cacheLRU = new HashMap<>();
	private Map<String, Map<String, Integer>> cacheElements = new HashMap<>();

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cacheLRU == null) ? 0 : cacheLRU.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cache other = (Cache) obj;
		if (cacheLRU == null) {
			if (other.cacheLRU != null)
				return false;
		} else if (!cacheLRU.equals(other.cacheLRU))
			return false;
		return true;
	}

	Map<String, Map<String, Integer>> getCacheElements() {
		return cacheElements;
	}

	Map<String, Integer> getCacheLRU() {
		return cacheLRU;
	}

	void addToCache(String input, HashMap<String, Integer> calculatedResult) {
		Integer val = cacheLRU.get(input);

		if (cacheLRU.containsKey(input) == true) {
			cacheLRU.put(input, val + 1);

		} else {
			cacheLRU.put(input, 1);
			getCacheElements().put(input, calculatedResult);
		}
	}

	void removeFromCache(Map<String, Integer> inputCache) {
		int step = 0;
		for (Map.Entry<String, Integer> entry : inputCache.entrySet()) {
			if (step > SIZE_CACHE - 1) {
				cacheLRU.remove(entry.getKey());
				getCacheElements().remove(entry.getKey());
			}
			step++;
		}
	}

	Map<String, Integer> sortByValue(Map<String, Integer> unSortedMap) {
		List<Map.Entry<String, Integer>> list = new LinkedList<Map.Entry<String, Integer>>(unSortedMap.entrySet());
		Map<String, Integer> sortedMap = new HashMap<String, Integer>();

		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
			public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
				return (o2.getValue()).compareTo(o1.getValue());
			}
		});
		return sortedMap;
	}

}
