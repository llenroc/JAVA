package com.foxminded.oleksiisaiun.task5.collections;

public class MainFrequency {

	public static void main(String[] args) {

		String input = "Hello World!!!";
		Frequency freq = new Frequency();
		System.out.println(freq.outputTotalChars(input));
	}

}
