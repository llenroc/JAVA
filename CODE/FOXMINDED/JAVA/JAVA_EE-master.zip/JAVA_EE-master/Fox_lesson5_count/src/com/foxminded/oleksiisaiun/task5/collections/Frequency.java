package com.foxminded.oleksiisaiun.task5.collections;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Frequency {

	Cache cache=new Cache();
	public String outputTotalChars(String input) {
		Map<String, Integer> resultFrequency = determineTotalChars(input, cache);
		String output = "";

		for (Entry<String, Integer> entry : resultFrequency.entrySet()) {
			String key = entry.getKey().toString();
			Integer value = entry.getValue();
			output = output + "\"" + key + "\"" + " = " + value + "\n";
		}
		return output;
	}
	
	HashMap<String, Integer> countChars(String input) {
		HashMap<String, Integer> result = new HashMap<>();

		for (int j = 0; j < input.length(); j++) {
			String key = String.valueOf(input.charAt(j));
			Integer freq = result.get(key);
			result.put(key, (freq == null) ? 1 : freq + 1);
		}
		return result;
	}
	
	private Map<String, Integer> determineTotalChars(String input, Cache cache) {
		Map<String, Integer> result;		
		Map<String, Integer> sortedCacheLRU = cache.sortByValue(cache.getCacheLRU());
		if (cache.getCacheElements().containsKey(input) == true) {
			result = cache.getCacheElements().get(input);
		} else {
			HashMap<String, Integer> amountChars = countChars(input);
			result = amountChars;
			cache.addToCache(input,amountChars);
		}
		cache.removeFromCache(sortedCacheLRU);
		return result;
	}

}
