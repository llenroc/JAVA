package com.foxminded.oleksiisaiun.task5.collections;

import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

public class TestFrequency {
	private String display(Map<String, Integer> frequency) {

		String result = "";
		for (Entry<String, Integer> entry : frequency.entrySet()) {
			String key = entry.getKey().toString();
			Integer value = entry.getValue();
			result = result + "\"" + key + "\"" + " = " + value + "\n";
		}
		return result;
	}

	@Test
	public void compareExecutionTime() {
		long t1, t2, t3, t4;
		String input1 = "Kaiserslautern";
		String input2 = "Frankfurt";
		String input3 = "Munich";
		String input4 = "Berlin";
		String input5 = "Dusseldorf";

		// data is not caching
		t1 = System.nanoTime();
		Frequency freq_nocaching = new Frequency();
		freq_nocaching.outputTotalChars(input1);
		t2 = System.nanoTime();

		// data is caching
		t3 = System.nanoTime();
		Cache cacheCaseCaching = new Cache();
		Frequency freq_caching = new Frequency();
		cacheCaseCaching.addToCache(input1, freq_caching.countChars(input1));
		cacheCaseCaching.addToCache(input1, freq_caching.countChars(input1));
		cacheCaseCaching.addToCache(input1, freq_caching.countChars(input1));
		cacheCaseCaching.addToCache(input2, freq_caching.countChars(input2));
		cacheCaseCaching.addToCache(input3, freq_caching.countChars(input3));
		cacheCaseCaching.addToCache(input4, freq_caching.countChars(input4));
		cacheCaseCaching.addToCache(input5, freq_caching.countChars(input5));
		freq_caching.outputTotalChars(input1);
		t4 = System.nanoTime();

		assertTrue("Failed - data is not caching", t2 - t1 > t4 - t3);
	}

	@Test
	public void test_HelloWorld() {
		String input = "Hello World!!!";
		Frequency freq = new Frequency();
		String inputCount = freq.outputTotalChars(input);

		Map<String, Integer> mapCheck = new HashMap<>();
		mapCheck.put("H", 1);
		mapCheck.put("e", 1);
		mapCheck.put("l", 3);
		mapCheck.put("o", 2);
		mapCheck.put(" ", 1);
		mapCheck.put("W", 1);
		mapCheck.put("r", 1);
		mapCheck.put("d", 1);
		mapCheck.put("!", 3);
		String checkCount = display(mapCheck);

		Assert.assertEquals(inputCount, checkCount);
	}

	@Test
	public void test_aaaAaaBba() {
		String input = "aaaAaaBba";
		Frequency freq = new Frequency();
		String inputCount = freq.outputTotalChars(input);

		Map<String, Integer> mapCheck = new HashMap<>();
		mapCheck.put("a", 6);
		mapCheck.put("A", 1);
		mapCheck.put("B", 1);
		mapCheck.put("b", 1);
		String checkCount = display(mapCheck);

		Assert.assertEquals(inputCount, checkCount);
	}

	@Test
	public void test_11234560121() {
		String input = "11234560121";
		Frequency freq = new Frequency();
		String inputCount = freq.outputTotalChars(input);

		Map<String, Integer> mapCheck = new HashMap<>();
		mapCheck.put("1", 4);
		mapCheck.put("2", 2);
		mapCheck.put("3", 1);
		mapCheck.put("4", 1);
		mapCheck.put("5", 1);
		mapCheck.put("6", 1);
		mapCheck.put("0", 1);
		String checkCount = display(mapCheck);

		Assert.assertEquals(inputCount, checkCount);
	}

	@Test
	public void test_spaceSingle() {
		String input = " ";
		Frequency freq = new Frequency();
		String inputCount = freq.outputTotalChars(input);

		Map<String, Integer> mapCheck = new HashMap<>();
		mapCheck.put(" ", 1);
		String checkCount = display(mapCheck);

		Assert.assertEquals(inputCount, checkCount);
	}

	@Test
	public void test_spaceMultiple() {
		String input = "    ";
		Frequency freq = new Frequency();
		String inputCount = freq.outputTotalChars(input);

		Map<String, Integer> mapCheck = new HashMap<>();
		mapCheck.put(" ", 4);
		String checkCount = display(mapCheck);

		Assert.assertEquals(inputCount, checkCount);
	}
}
