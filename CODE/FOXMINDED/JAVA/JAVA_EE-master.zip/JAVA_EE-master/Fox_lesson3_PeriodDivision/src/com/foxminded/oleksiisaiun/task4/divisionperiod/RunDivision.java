package com.foxminded.oleksiisaiun.task4.divisionperiod;
	public class RunDivision {

		public static void main(String[] args) {
			int dividend = 78459; // input
		    int divisor = 4; // input
		    
			try {
				CalcDivision division = new CalcDivision();
				DivisionData data = division.divide(dividend, divisor);
				FormatDivision format = new FormatDivision();
				
				System.out.println(format.formatResult(data));
			} catch (ArithmeticException e) {
				System.out.print("division_by_zero");
			}

		}

	}
