package com.foxminded.oleksiisaiun.task4.divisionperiod;

public class FormatDivision {

	public String formatResult(DivisionData data) {
		int dividendOut = Math.abs(data.getDividend());
		int divisorOut = Math.abs(data.getDivisor());
		String space = "";
		int[] remainderInterim = data.getDataRemainderInterim();
		int[] differenceInterim = data.getDataDifferenceInterim();
		int remainder = data.getDataRemainder();	
		int arraySize = remainderInterim.length;
		String output = "";
		
		for (int j = 0; j < remainderInterim.length; j++) {
			if ( j == 0) {
				output=space + dividendOut + "|" + divisorOut+"\n"+
				space + "-" + generateSpaces(returnLength(dividendOut)) + "----------"+"\n"+
				space + differenceInterim[j] + generateSpaces(returnLength(dividendOut)) + data.getDataQuotient()+"\n"+
				space + "__"+"\n";
				if (arraySize == 1) {
					output=output+space + " " + remainder;
				}

			} else if ( j > 0) {
				output=output+space + " " + remainderInterim[j]+"\n"+
				space + "-"+"\n"+
				space + " " + differenceInterim[j]+"\n"+
				space + "___"+"\n";
				if (j == arraySize - 1) {
					output=output+space + " " + remainder;
				}
				space = space + " ";
			}
		}
		return output;
	}
	
	private String generateSpaces(int length) {
		String space = "";
		for (int j = 0; j < length; j++) {
			space = space + " ";
		}
		return space;
	}

	private int returnLength(int value) {
		return String.valueOf(value).length();
	}

}
