package com.foxminded.oleksiisaiun.task4.divisionperiod;
public class DivisionData {
	private int dividend;
	private int divisor;
	private int[] dataRemainderInterim;
	private int[] dataDifferenceInterim;
	private int dataRemainder;
	private String dataQuotient;

	public DivisionData() {
	}

	public int getDividend() {
		return dividend;
	}

	public void setDividend(int dividend) {
		this.dividend = dividend;
	}

	public int getDivisor() {
		return divisor;
	}

	public void setDivisor(int divisor) {
		this.divisor = divisor;
	}

	public int[] getDataRemainderInterim() {
		return dataRemainderInterim;
	}

	public void setDataRemainderInterim(int[] dataRemainderInterim) {
		this.dataRemainderInterim = dataRemainderInterim;
	}

	public int[] getDataDifferenceInterim() {
		return dataDifferenceInterim;
	}

	public void setDataDifferenceInterim(int[] dataDifferenceInterim) {
		this.dataDifferenceInterim = dataDifferenceInterim;
	}

	public int getDataRemainder() {
		return dataRemainder;
	}

	public void setDataRemainder(int dataRemainder) {
		this.dataRemainder = dataRemainder;
	}

	public String getDataQuotient() {
		return dataQuotient;
	}

	public void setDataQuotient(String dataQuotient) {
		this.dataQuotient = dataQuotient;
	}



}
