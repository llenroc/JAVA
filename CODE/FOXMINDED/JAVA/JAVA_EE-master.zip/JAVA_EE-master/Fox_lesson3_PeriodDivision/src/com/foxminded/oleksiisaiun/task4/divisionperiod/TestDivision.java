package com.foxminded.oleksiisaiun.task4.divisionperiod;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.junit.jupiter.api.Test;

public class TestDivision {
	// --------------------------------------
	// 1. Case: 2/1=2+0
	@Test
	public void testDivision_2_div_1() {

		int inputDividend = 2;
		int inputDivisor = 1;
		CalcDivision calc=new  CalcDivision();
		DivisionData data = calc.divide(inputDividend, inputDivisor);		
		
		String inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();		
		String checkQuotienter = "2";
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}
	
	// --------------------------------------
	// 2. Case: 780/12=65+0
	@Test
	public void testDivision_780_div_12() {
		int inputDividend = 780;
		int inputDivisor = 12;
		CalcDivision calc=new  CalcDivision();
		DivisionData data = calc.divide(inputDividend, inputDivisor);		
		
		String inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		String checkQuotienter = "65";
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}


	// --------------------------------------
	// 3. Case: 1340/68=19.7+4
	@Test
	public void testDivision_1340_div_68() {
		int inputDividend = 1340;
		int inputDivisor = 68;
		CalcDivision calc=new  CalcDivision();
		DivisionData data = calc.divide(inputDividend, inputDivisor);		
		
		String inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		String checkQuotienter = "19.7";
		int checkRemainder = 4;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}


	// --------------------------------------
	// 4. Case: 78945/4=19736.25+0
	@Test
	public void testDivision_78945_div_4() {
		int inputDividend = 78945;
		int inputDivisor = 4;
		CalcDivision calc=new  CalcDivision();
		DivisionData data = calc.divide(inputDividend, inputDivisor);		
		
		String inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		String checkQuotienter = "19736.25";
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}
	
	// --------------------------------------
	// 5. Case: 78459/4=19614.75+0
	@Test
	public void testDivision_78459_div_4() {
		int inputDividend = 78459;
		int inputDivisor = 4;
		CalcDivision calc=new  CalcDivision();
		DivisionData data = calc.divide(inputDividend, inputDivisor);		
		
		String inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		String checkQuotienter = "19614.75";
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 6. Case: 1000/3=333.33333+1
	@Test
	public void testDivision_1000_div_3() {
		int inputDividend = 1000;
		int inputDivisor = 3;
		CalcDivision calc=new  CalcDivision();
		DivisionData data = calc.divide(inputDividend, inputDivisor);		
		
		String inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		String checkQuotienter = "333.33333";
		int checkRemainder = 3;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 7. Case: 7/12=0.583333+1
	@Test
	public void testDivision_7_div_12() {
		int inputDividend = 7;
		int inputDivisor = 12;
		CalcDivision calc=new  CalcDivision();
		DivisionData data = calc.divide(inputDividend, inputDivisor);		
		
		String inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		String checkQuotienter = "0.583333";
		int checkRemainder = 12;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}
	
	// --------------------------------------
	// 8. Case: 25/39=0.641+25
	@Test
	public void testDivision_25_div_39() {
		int inputDividend = 25;
		int inputDivisor = 39;
		CalcDivision calc=new  CalcDivision();
		DivisionData data = calc.divide(inputDividend, inputDivisor);		
		
		String inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		String checkQuotienter = "0.641";
		int checkRemainder = 25;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}
}
