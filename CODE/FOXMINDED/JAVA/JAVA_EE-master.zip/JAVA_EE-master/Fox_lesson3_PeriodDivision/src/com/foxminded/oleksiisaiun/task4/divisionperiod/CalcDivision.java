package com.foxminded.oleksiisaiun.task4.divisionperiod;

public class CalcDivision {
	public DivisionData divide(int inputDividend, int inputDivisor) {
		DivisionData data = new DivisionData();
		int[] remainderInterim = buildRemainderInterim(inputDividend, inputDivisor);
		int[] differenceInterim = minusBetweenInterimMembers(inputDividend, inputDivisor);
		int remainder = retrieveLastRemainder(inputDividend, inputDivisor);
		String quotient = addDot(buildQuotient(inputDividend, inputDivisor),inputDividend, inputDivisor);
		
		data.setDividend(inputDividend);
		data.setDivisor(inputDivisor);
		data.setDataRemainderInterim(remainderInterim);
		data.setDataDifferenceInterim(differenceInterim);
		data.setDataRemainder(remainder);
		data.setDataQuotient(quotient); 


		return data;
	}

	private String[] parse(int input) {
		String dividend = String.valueOf(input);
		String[] arr = new String[dividend.length()];

		for (int i = 0; i < dividend.length(); i++) {
			arr[i] = Character.toString(dividend.charAt(i));
		}
		return arr;
	}

	private int defineDividendDigits(int inputDividend, int inputDivisor) {
		String[] dividend = parse(inputDividend);
		int j = 0;
		int remainder = 0;
		String output = dividend[j];

		while (j < dividend.length - 1) {
			remainder = Integer.valueOf(output) / inputDivisor;
			if (remainder > 0) {
				break;
			}
			j++;
			output = output + dividend[j];
		}
		return Integer.valueOf(output);
	}

	private String addLeadingZeros(String remainder, int divisor) {
		String output = "";
		boolean checkValue1 = Integer.valueOf(remainder) == 0;
		boolean checkValue2 = Integer.valueOf(remainder) / divisor == 0;

		if (checkValue1) {
			for (int j = 0; j < remainder.length() - 1; j++) {
				output = "0" + output;
			}
		} else if (checkValue2) {
			output = "0";
		}
		return output;
	}

	private int buildQuotientIndividual(int inputDividend, int inputDivisor) {
		String[] dividend = parse(inputDividend);
		int quotientOut = 0;
		String remainderStep = "";
		String remainder;
		String step = "";

		for (int j = 0; j < dividend.length; j++) {
			step = step + dividend[j];
			int quotientStep = Integer.valueOf(step) / inputDivisor;
			remainderStep = String.valueOf(inputDividend).substring(j + 1);
			remainder = Integer.valueOf(step) - quotientStep * inputDivisor + remainderStep;
			if (quotientStep > 0 && remainderStep.length() > 0) {
				quotientOut = Integer.valueOf(quotientStep + addLeadingZeros(remainder, inputDivisor));
				break;
			} else if (quotientStep > 0) {
				quotientOut = quotientStep;
				break;
			}
		}
		return quotientOut;
	}

	private int retrieveRestOfDividendAfterDivision(int inputDividend, int inputDivisor) {
		String[] dividend = parse(inputDividend);
		String remainderStep = "";
		String step = "";
		int output;
		int minus;

		for (int j = 0; j < dividend.length; j++) {
			step = step + dividend[j];
			remainderStep = String.valueOf(inputDividend).substring(j + 1);
			if (Integer.valueOf(step) / inputDivisor > 0) {
				break;
			}
		}
		minus = defineDividendDigits(inputDividend, inputDivisor)
				- (inputDivisor * buildQuotientIndividual(inputDividend, inputDivisor));
		output = Integer.valueOf(minus + remainderStep);
		return output;
	}

	private String buildQuotient(int inputDividend, int inputDivisor) {
		int j = 0;
		int quotient = 0;
		String output = "";
		
		if (inputDividend != 0) {
			do {
				inputDividend = Integer
						.valueOf(inputDividend + addLeadingZeros(String.valueOf(inputDividend), inputDivisor));
				quotient = inputDividend / inputDivisor;
				if (quotient == 0) {
					break;
				} else {
					inputDividend = inputDividend - quotient * inputDivisor;// loop
					output = output +quotient;
					j++;
				}
			} while (j <= 6);//maximum length of quotient after period
		}
		return output;
	}
	
	private String addDot(String input, int inputDividend, int inputDivisor) {
		int quotient=inputDividend/inputDivisor;
		int mod=inputDividend%inputDivisor;
		int index=String.valueOf(quotient).length();
		String output="";
		
		if(quotient==0 && mod!=0)
		{
			output="0."+input;
		}
		else if (quotient>0 && mod!=0)
		{
			output=input.substring(0, index)+"."+input.substring( index);
		}
		else
		{
			output=input;
		}

		return output;
	}
	
	private int[] buildRemainderInterim(int inputDividend, int inputDivisor) {
		int size = buildQuotient(inputDividend, inputDivisor).length();
		int[] output = new int[size];
		int j = 0;
		int rest;

		do {
			inputDividend = Integer
					.valueOf(inputDividend + addLeadingZeros(String.valueOf(inputDividend), inputDivisor));
			rest = retrieveRestOfDividendAfterDivision(inputDividend, inputDivisor);
			output[j] = defineDividendDigits(inputDividend, inputDivisor);
			inputDividend = rest; // loop
			j++;
		} while (j < size);
		return output;
	}

	private int[] minusBetweenInterimMembers(int inputDividend, int inputDivisor) {
		int input = Integer.valueOf(buildQuotient(inputDividend, inputDivisor));
		int size = String.valueOf(input).length();
		String[] quotientInterim = parse(input);
		int[] output = new int[size];

		for (int j = 0; j < size; j++) {
			output[j] = Integer.valueOf(quotientInterim[j]) * inputDivisor;
		}

		return output;
	}

	private int retrieveLastRemainder(int inputDividend, int inputDivisor) {
		int size = buildRemainderInterim(inputDividend, inputDivisor).length;
		int[] remainder = buildRemainderInterim(inputDividend, inputDivisor);
		int[] difference = minusBetweenInterimMembers(inputDividend, inputDivisor);
		int lastRemainder = remainder[size-1] - difference[size-1];
		
		return lastRemainder;
	}


}
