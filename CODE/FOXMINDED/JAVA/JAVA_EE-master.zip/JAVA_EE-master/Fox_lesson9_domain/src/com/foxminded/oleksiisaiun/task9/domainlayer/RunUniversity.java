package com.foxminded.oleksiisaiun.task9.domainlayer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class RunUniversity {
	public static void main(final String[] args) {
		University univer = new University();

		List<Student> students1 = new ArrayList<Student>();
		students1.add(new Student("Ivan", "Borisav"));
		students1.add(new Student("John", "Maclein"));
		students1.add(new Student("Alex", "Dimitrov"));

		List<Student> students2 = new ArrayList<Student>();
		students2.add(new Student("Sue", "Jenny"));
		students2.add(new Student("See", "Jackolin"));
		students2.add(new Student("Klevin", "Tcheskov"));
		students2.add(new Student("Yuliya", "Kioto"));

		Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
		Teacher teacher2 = new Teacher("Oleg", "Klyosov");
		Teacher teacher3 = new Teacher("Vera", "Virchenko");
		Teacher teacher4 = new Teacher("Petr", "Sshkabara");
		Teacher teacher5 = new Teacher("Nokolayi", "Petrenk");
		Teacher teacher6 = new Teacher("Sergei", "Saenko");
		Teacher teacher7 = new Teacher("Pavel", "Ageev");
		Teacher teacher8 = new Teacher("Denis", "Ryndin");
		Teacher teacher9 = new Teacher("Oleg", "Popov");
		Teacher teacher10 = new Teacher("Pavel", "Zalevskyi");

		LocalDate day1 = LocalDate.of(2019, 2, 5);
		LocalDate day2 = LocalDate.of(2019, 2, 6);
		LocalDate day3 = LocalDate.of(2019, 2, 7);
		LocalTime time1 = LocalTime.of(8, 00);
		LocalTime time2 = LocalTime.of(9, 30);
		LocalTime time3 = LocalTime.of(10, 30);
		LocalTime time4 = LocalTime.of(12, 00);
		LocalTime time5 = LocalTime.of(13, 00);

		Lesson lesson1 = new Lesson(LocalDateTime.of(day1, time1), "Mathematical Analysis", students1, teacher1, "346");
		Lesson lesson2 = new Lesson(LocalDateTime.of(day1, time2), "Hydromechanics", students1, teacher2, "986");
		Lesson lesson3 = new Lesson(LocalDateTime.of(day1, time3), "Higher Algebra", students1, teacher4, "568");
		Lesson lesson4 = new Lesson(LocalDateTime.of(day1, time4), "Differential Equations", students1, teacher1,
				"146");

		Lesson lesson5 = new Lesson(LocalDateTime.of(day2, time1), "Theory of Probabilities", students2, teacher1,
				"346");
		Lesson lesson6 = new Lesson(LocalDateTime.of(day2, time2), "Number Theory", students2, teacher3, "127");
		Lesson lesson7 = new Lesson(LocalDateTime.of(day2, time3), "General Topology and Geometry", students2, teacher2,
				"777");
		Lesson lesson8 = new Lesson(LocalDateTime.of(day2, time4), "Discrete Mathematics", students2, teacher3, "401");

		Lesson lesson9 = new Lesson(LocalDateTime.of(day3, time1), "Mathematical Analysis", students1, teacher1, "346");
		Lesson lesson10 = new Lesson(LocalDateTime.of(day3, time2), "Statistics", students1, teacher2, "986");
		Lesson lesson11 = new Lesson(LocalDateTime.of(day3, time3), "English", students1, teacher6, "568");
		Lesson lesson12 = new Lesson(LocalDateTime.of(day3, time4), "Mathematical Analysis", students1, teacher1,
				"346");
		Lesson lesson13 = new Lesson(LocalDateTime.of(day3, time5), "Higher Algebra", students2, teacher5, "440");

		univer.addLesson(lesson1);
		univer.addLesson(lesson2);
		univer.addLesson(lesson3);
		univer.addLesson(lesson4);
		univer.addLesson(lesson5);
		univer.addLesson(lesson6);
		univer.addLesson(lesson7);
		univer.addLesson(lesson8);
		univer.addLesson(lesson9);
		univer.addLesson(lesson10);
		univer.addLesson(lesson11);
		univer.addLesson(lesson12);
		univer.addLesson(lesson13);

		// RUN
			LocalDate inputDate = LocalDate.of(2019, 2,6);
			for (Lesson lesson : univer.getScheduleByDay(teacher3, inputDate)) {
				System.out.println(lesson.toString());
			}

	}
}