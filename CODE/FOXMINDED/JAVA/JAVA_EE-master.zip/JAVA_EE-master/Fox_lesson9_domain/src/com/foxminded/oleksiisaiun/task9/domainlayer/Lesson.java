package com.foxminded.oleksiisaiun.task9.domainlayer;

import java.time.LocalDateTime;
import java.util.List;
public class Lesson extends Person {
	private LocalDateTime day;
	private String subject;
	private List<Student> students;
	private Teacher teacher;
	private String room;

	public Lesson(LocalDateTime day, String subject, List<Student> students, Teacher teacher, String room
			) {
		super();
		this.day = day;
		this.subject = subject;
		this.students = students;
		this.teacher = teacher;
		this.room = room;
	}

	@Override
	public String toString() {
		String resultWithoutStudent = "LESSON : \n" + day + ", subject=" + subject + ", "
				+ teacher + ", room=" + room + "\n";
		String resultStudent = "     ";
		for (Student s : students) {
			resultStudent = String.valueOf(resultStudent) + s.toString() + "\n     ";
		}

		String output = resultWithoutStudent + resultStudent + "\n---------------------------------\n";
		return output;
	}

	LocalDateTime getDay() {
		return day;
	}

	String getSubject() {
		return subject;
	}

	List<Student> getStudents() {
		return students;
	}

	Teacher getTeacher() {
		return teacher;
	}

	String getRoom() {
		return room;
	}

	
}
