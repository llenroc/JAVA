package com.foxminded.oleksiisaiun.task9.domainlayer;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
//
public class University {

	private Set<Teacher> teachersAll = new HashSet<>();
	private Set<Student> studentsAll = new HashSet<>();
	public Set<Lesson> lessonsAll = new HashSet<>();

	public void enrollStudent(String firstName, String lastName) {
		Student student = new Student(firstName, lastName);
		studentsAll.add(student);
	}

	public void excludeStudent(String firstName, String lastName) {
		Student student = new Student(firstName, lastName);
		studentsAll.remove(student);
	}

	public void hireTeacher(String firstName, String lastName) {
		Teacher teacher = new Teacher(firstName, lastName);
		teachersAll.add(teacher);
	}

	public void fireTeacher(String firstName, String lastName) {
		Teacher teacher = new Teacher(firstName, lastName);
		teachersAll.remove(teacher);
	}

	public void addLesson(Lesson lesson) {
		lessonsAll.add(lesson);
	}

	public void removeLesson(Lesson lesson) {
		lessonsAll.remove(lesson);
	}

	public List<Lesson> getScheduleByDay(Person person, LocalDate inputDate) { 
		List<Lesson> searchedLessons = new ArrayList<>();
		
		if (person instanceof Student) {
				for (Lesson lesson : lessonsAll) {

					if (lesson.getStudents().contains(person) && lesson.getDay().toLocalDate().equals(inputDate)) {
						searchedLessons.add(lesson);
					}
			}

		} else if (person instanceof Teacher) {
			for (Lesson lesson : lessonsAll) {				
					
					if (lesson.getTeacher().equals(person) && lesson.getDay().toLocalDate().equals(inputDate)

					) {
						searchedLessons.add(lesson);
					}
				}
			
		}
		return searchedLessons;
	}

	public List<Lesson> getScheduleByMonth(Person person, LocalDate inputDate) { 
		List<Lesson> searchedLessons = new ArrayList<>();
	
		if (person instanceof Student) {
			for (Lesson lesson : lessonsAll) {
					if (   lesson.getStudents().contains(person) 
						&& lesson.getDay().getYear() == inputDate.getYear() 
						&& lesson.getDay().getMonth().equals(inputDate.getMonth()) ) {
						searchedLessons.add(lesson);					
				}
			}
			

		} else if (person instanceof Teacher) {
			for (Lesson lesson : lessonsAll) {
					if (       lesson.getTeacher().equals(person) 
							&& lesson.getDay().getYear() == inputDate.getYear() 
							&& lesson.getDay().getMonth().equals(inputDate.getMonth())

					) {
						searchedLessons.add(lesson);
					}				
			}
		}
		return searchedLessons;
	}
	
	// getters and setters
	public List<Lesson> getScheduleAll() {
		return getLessonsAll();
	}

	public Set<Teacher> getTeachersAll() {
		return teachersAll;
	}

	public Set<Student> getStudentsAll() {
		return studentsAll;
	}

	List<Lesson> getLessonsAll() {
		return (List<Lesson>) lessonsAll;
	}

}
