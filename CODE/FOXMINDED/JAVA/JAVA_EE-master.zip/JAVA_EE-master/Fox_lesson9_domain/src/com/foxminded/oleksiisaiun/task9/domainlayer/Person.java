package com.foxminded.oleksiisaiun.task9.domainlayer;

public abstract class Person {

}
