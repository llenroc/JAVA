package com.foxminded.oleksiisaiun.task9.domainlayer;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.Test;


public class TestUniversity {
	@Test
	public void testCheck_student() {
		University univer = new University();
		List<Student> students1 = new ArrayList<Student>();
		students1.add(new Student("Ivan", "Borisav"));
		students1.add(new Student("John", "Maclein"));
		students1.add(new Student("Alex", "Dimitrov"));
		Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
		LocalDate day1 = LocalDate.of(2019, 2, 5);
		LocalTime time1 = LocalTime.of(8, 00);
		Lesson lesson1 = new Lesson(LocalDateTime.of(day1, time1), "Mathematical Analysis", students1, teacher1, "346");

		Student studentInput = lesson1.getStudents().get(2);
		Student studentTest = new Student("Alex", "Dimitrov");
		Assert.assertEquals(studentInput, studentTest);
	}

	@Test
	public void testCheck_lessonName() {
		University univer = new University();
		List<Student> students1 = new ArrayList<Student>();
		students1.add(new Student("Ivan", "Borisav"));
		students1.add(new Student("John", "Maclein"));
		students1.add(new Student("Alex", "Dimitrov"));
		Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
		LocalDate day1 = LocalDate.of(2019, 2, 5);
		LocalTime time1 = LocalTime.of(8, 00);
		Lesson lesson1 = new Lesson(LocalDateTime.of(day1, time1), "Mathematical Analysis", students1, teacher1, "346");

		String lessonNameInput = lesson1.getSubject();
		String lessonNameOutput = "Mathematical Analysis";
		Assert.assertEquals(lessonNameInput, lessonNameOutput);
	}

	@Test
	public void testCheck_teacher() {
		University univer = new University();
		List<Student> students1 = new ArrayList<Student>();
		students1.add(new Student("Ivan", "Borisav"));
		students1.add(new Student("John", "Maclein"));
		students1.add(new Student("Alex", "Dimitrov"));
		Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
		LocalDate day1 = LocalDate.of(2019, 2, 5);
		LocalTime time1 = LocalTime.of(8, 00);
		Lesson lesson1 = new Lesson(LocalDateTime.of(day1, time1), "Mathematical Analysis", students1, teacher1, "346");

		Teacher teacherInput = lesson1.getTeacher();
		Teacher teacherOutput = new Teacher("Valeryi", "Buldigin");
		Assert.assertEquals(teacherInput,  teacherOutput);
	}

}
