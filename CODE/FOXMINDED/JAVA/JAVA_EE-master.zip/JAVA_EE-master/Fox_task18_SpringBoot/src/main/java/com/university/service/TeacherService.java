package com.university.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.university.entity.Teacher;
import com.university.repository.TeacherRepository;

@Service
public class TeacherService {
    private TeacherRepository teacherRepository;

    @Autowired
    public TeacherService(TeacherRepository teacherRepository) {
        this.teacherRepository = teacherRepository;
    }

    public void insert(Teacher teacher) {
            teacherRepository.save(teacher);
    }

    public void update(Teacher teacher) {
        teacherRepository.update(teacher.getFirstName(), teacher.getLastName(), teacher.getId());
    }

    public void delete(Teacher teacher) {
        teacherRepository.delete(teacher);
    }

    public List<Teacher> findAll() {
        return (List<Teacher>) teacherRepository.findAll();
    }


    public Teacher findById(int teacherId) {
        return teacherRepository.findById(teacherId)
                                                    .orElseThrow(() -> new ServiceException("Student does not exist"));
    }

}
