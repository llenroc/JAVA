package com.university.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.university.entity.Lesson;
import com.university.service.LessonService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value = "University Management System", description = "Operations to manage teachers, students and their schedules in University")
@RestController
public class UniversityRestController {

    @Autowired
    private LessonService lessonService;

    @ApiOperation(value = "View all lessons", response = List.class)
    @RequestMapping(value = "/rest/showAllLessons", method = RequestMethod.GET)
    @ResponseBody
    public List<Lesson> listLessonsRequestRest() {
        return lessonService.findAll();
    }

    @ApiOperation(value = "Find a lesson by id", response = List.class)
    @RequestMapping(value = "/rest/showLesson/{id}", method = RequestMethod.GET)
    public @ResponseBody Lesson listLessonByIdRest(@PathVariable("id") int lessonId) {
        return lessonService.findById(lessonId);
    }

    @ApiOperation(value = "add new lesson", response = List.class)
    @RequestMapping(value = "/rest/addLesson", method = RequestMethod.POST)
    public @ResponseBody Lesson addLessonRequest(@RequestBody Lesson lesson) {
        lessonService.insert(lesson);
        return lesson;
    }

    @ApiOperation(value = "update lesson by id", response = List.class)
    @RequestMapping(value = "/rest/updateLesson/{id}", method = RequestMethod.POST)
    public @ResponseBody Lesson updateLessonByIdRest(@PathVariable("id") int lessonId) {
        Lesson lesson = lessonService.findById(lessonId);
        lessonService.delete(lesson);
        return lesson;
    }

    @ApiOperation(value = "delete lesson by id", response = List.class)
    @RequestMapping(value = "/rest/deleteLesson/{id}", method = RequestMethod.PUT)
    public @ResponseBody Lesson deleteLessonByIdRest(@PathVariable("id") int lessonId) {
        Lesson lesson = lessonService.findById(lessonId);
        lessonService.delete(lesson);
        return lesson;
    }
}
