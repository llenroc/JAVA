package com.university.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.university.entity.Student;
import com.university.repository.StudentRepository;

@Service
public class StudentService {
    private StudentRepository studentRepository;

    @Autowired
    public StudentService(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public void insert(Student student) {
        studentRepository.save(student);
    }

    public void update(Student student) {
        studentRepository.update(student.getFirstName(), student.getLastName(), student.getId());
    }

    public void delete(Student student) {
        studentRepository.delete(student);
    }

    public List<Student> findAll() {
        return (List<Student>) studentRepository.findAll();
    }

    public Student findById(int studentId) {
        return studentRepository.findById(studentId)
                                                    .orElseThrow(() -> new ServiceException("Student does not exist"));
    }

}
