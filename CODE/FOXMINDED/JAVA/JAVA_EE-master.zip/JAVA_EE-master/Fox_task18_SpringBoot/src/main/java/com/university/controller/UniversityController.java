package com.university.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.university.entity.Lesson;
import com.university.service.LessonService;

@Controller
public class UniversityController {
    private static final String LESSON_MODEL_ADD_LESSON_ATTRIBUTE_NAME = "the_lesson";
    private static final String LESSON_MODEL_UPDATE_LESSON_ATTRIBUTE_NAME = "the_lesson";
    private static final String ALL_LESSONS_MODEL_ATTRIBUTE_NAME = "lessons";
    private static final String LESSON_ID_MODEL_UPDATE_REQUEST_PARAM_NAME = "lessonId";
    private static final String LESSON_ID_MODEL_DELETE_REQUEST_PARAM_NAME = "lessonId";
    private static final String HOME_JSP_PAGE_NAME = "home";
    private static final String LESSON_FORM_JSP_PAGE_NAME = "lesson-form";
    private static final String ALL_LESSONS_REDIRECT_JSP_PAGE_NAME = "redirect:/showAllLessons";

    @Autowired
    private LessonService lessonService;

    @RequestMapping(value = "/showAllLessons", method = RequestMethod.GET)
    @ExceptionHandler(value = Exception.class)
    public String listLessonsRequest(Model model) throws Exception {
        List<Lesson> lessons = lessonService.findAll();
        model.addAttribute(ALL_LESSONS_MODEL_ATTRIBUTE_NAME, lessons);
        return HOME_JSP_PAGE_NAME;
    }

    @RequestMapping(value = "/addLesson", method = RequestMethod.POST)
    @ExceptionHandler(value = Exception.class)
    public String addLessonRequest(@Valid @ModelAttribute(LESSON_MODEL_ADD_LESSON_ATTRIBUTE_NAME) Lesson lesson,
            BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return LESSON_FORM_JSP_PAGE_NAME;
        }
        lessonService.insert(lesson);
        return ALL_LESSONS_REDIRECT_JSP_PAGE_NAME;
    }

    @RequestMapping(value = "/updateLesson", method = RequestMethod.GET)
    @ExceptionHandler(value = Exception.class)
    public String updateLessonRequest(@RequestParam(LESSON_ID_MODEL_UPDATE_REQUEST_PARAM_NAME) int id,
            Model model) {
        Lesson lessonToAdd = lessonService.findById(id);
        model.addAttribute(LESSON_MODEL_UPDATE_LESSON_ATTRIBUTE_NAME, lessonToAdd);
        return LESSON_FORM_JSP_PAGE_NAME;
    }

    @DeleteMapping(value = "/deleteLesson")
    @ExceptionHandler(value = Exception.class)
    public String deleteLessonRequest(@PathVariable(LESSON_ID_MODEL_DELETE_REQUEST_PARAM_NAME) int id) {
        Lesson lessonToDelete = lessonService.findById(id);
        lessonService.delete(lessonToDelete);
        return ALL_LESSONS_REDIRECT_JSP_PAGE_NAME;
    }

}
