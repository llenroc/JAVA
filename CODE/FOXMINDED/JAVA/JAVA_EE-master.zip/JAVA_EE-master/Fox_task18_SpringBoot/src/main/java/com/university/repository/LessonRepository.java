package com.university.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.university.entity.Lesson;

@Repository
public interface LessonRepository extends CrudRepository<Lesson, Integer> {
    public static final String SELECT_BY_BUSINESS_KEY_STATEMENT = "select l.id, l.start_datetime, l.subject_name, l.teacher_id, l.room from lessons l inner join teachers t on l.teacher_id=t.id where subject_name=?1 and start_datetime=?2 and t.first_name=?3 and t.last_name=?4";

    public static final String UPDATE_BY_ID_STATEMENT = "update Lesson l set l.day = ?1, l.subject = ?2, l.room = ?3 where l.id = ?4";

    @Modifying
    @Query(UPDATE_BY_ID_STATEMENT)
    public void update(String day, String subject, String room, int id);
}
