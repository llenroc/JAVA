package com.university.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.university.entity.Lesson;
import com.university.entity.Student;
import com.university.repository.LessonRepository;

@Service
public class LessonService {
    private LessonRepository lessonRepository;

    @Autowired
    public LessonService(LessonRepository lessonRepository) {
        this.lessonRepository = lessonRepository;
    }

    public void insert(Lesson lesson) {
        lessonRepository.save(lesson);
    }

    public void update(Lesson lesson) {
        lessonRepository.update(lesson.getDay(), lesson.getSubject(), lesson.getRoom(), lesson.getId());
    }

    public void delete(Lesson lesson) {
        lessonRepository.delete(lesson);
    }

    public List<Lesson> findAll() {
        return (List<Lesson>) lessonRepository.findAll();
    }

    public Lesson findById(int lessonId) {
        return lessonRepository.findById(lessonId).orElseThrow(() -> new ServiceException("Lesson does not exist"));
    }

    public List<Student> findStudentsById(int lessonId) {
        return lessonRepository.findById(lessonId)
                                                  .orElseThrow(() -> new ServiceException("Lesson does not exist"))
                                                  .getStudents();
    }

}
