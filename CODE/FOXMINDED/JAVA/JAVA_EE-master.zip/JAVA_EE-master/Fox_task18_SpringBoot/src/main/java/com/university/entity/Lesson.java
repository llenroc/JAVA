package com.university.entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.*;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "lessons")
@ApiModel(description = "Lesson model")
public class Lesson {
    public static final String VALID_ROOM_NOT_NULL_ERROR_MESSAGE = "Room number can not be null";
    public static final String VALID_ROOM_NOT_BLANK_ERROR_MESSAGE = "Room number can not be blank";
    public static final String VALID_ROOM_SIZE_ERROR_MESSAGE = "Room number has a wrong size";
    public static final String ROOM_NAME_NULL_ERROR_MESSAGE = "Room number is invalid";
    public static final String ROOM_NAME_PATTERN  = "^[a-zA-Z0-9]+$";

    @Id
    @GeneratedValue(generator = "seq_lesson", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "seq_lesson", sequenceName = "seq_lesson")
    @Column(name = "id")
    @ApiModelProperty(notes = "Generated unique Lesson ID")    
    private int id;

    @Column(name = "start_datetime")
    @ApiModelProperty(notes = "Start date and time of lesson")       
    private String day;

    @Column(name = "subject_name")
    @ApiModelProperty(notes = "subject of study")   
    private String subject;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "lessons_students", joinColumns = {
            @JoinColumn(name = "lesson_id", nullable = false, updatable = false) }, inverseJoinColumns = {
                    @JoinColumn(name = "student_id", nullable = false, updatable = false) })
    @JsonManagedReference
    @ApiModelProperty(notes = "assigned students")      
    private List<Student> students;

    @JoinColumn(name = "teacher_id")
    @OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @ApiModelProperty(notes = "assigned teacher")       
    private Teacher teacher;

    @NotNull(message = VALID_ROOM_NOT_NULL_ERROR_MESSAGE)
    @NotBlank(message = VALID_ROOM_NOT_BLANK_ERROR_MESSAGE)
    @Size(min = 1, max = 50, message = VALID_ROOM_SIZE_ERROR_MESSAGE)
    @Pattern(regexp = ROOM_NAME_PATTERN , message = ROOM_NAME_NULL_ERROR_MESSAGE)
    @Column(name = "room")
    @ApiModelProperty(notes = "assigned room")           
    private String room;

    public Lesson() {
    }

    public Lesson(String day, String subject, List<Student> students, Teacher teacher, String room) {
        this.day = day;
        this.subject = subject;
        this.students = students;
        this.teacher = teacher;
        this.room = room;
    }

    public int getId() {
        return id;
    }

    public void setId(int lessonID) {
        this.id = lessonID;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public int getTeacherID() {
        return getTeacher().getId();
    }

    public String getTeacherFirstName() {
        return getTeacher().getFirstName();
    }

    public String getTeacherLastName() {
        return getTeacher().getLastName();
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    @Override
    public String toString() {
        return "Lesson [lessonID=" + id + ", day=" + day + ", subject=" + subject + ", students=" + students
                + ", teacher=" + teacher + ", room=" + room + "]";
    }

}
