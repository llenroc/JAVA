package com.university.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "students")
@ApiModel(description = "Student model")
public class Student {
    @Id
    @GeneratedValue(generator = "seq_student", strategy = GenerationType.SEQUENCE)
    @Column(name = "id")
    @ApiModelProperty(notes = "Generated unique Student ID")
    private int id;

    @Column(name = "first_name")
    @ApiModelProperty(notes = "Student first name")
    private String firstName;

    @Column(name = "last_name")
    @ApiModelProperty(notes = "Student last name")
    private String lastName;

    @ManyToMany(fetch = FetchType.EAGER, mappedBy = "students")
    @JsonBackReference
    @ApiModelProperty(notes = "List of lessons assigned to student")
    private Set<Lesson> lessons = new HashSet<Lesson>(0);

    public Student() {
    }

    public Student(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Set<Lesson> getLessons() {
        return lessons;
    }

    public void setLessons(Set<Lesson> lessons) {
        this.lessons = lessons;
    }

    @Override
    public String toString() {
        return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + "]";
    }

}