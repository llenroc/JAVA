package com.university.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.university.entity.Teacher;

@Repository
public interface TeacherRepository extends CrudRepository<Teacher, Integer> {
    public static final String UPDATE_BY_ID_STATEMENT = "update Teacher t set t.firstName = ?1, t.lastName = ?2 where t.id = ?3";

    @Modifying
    @Query(UPDATE_BY_ID_STATEMENT)
    public void update(String firstName, String lastName, int id);
}
