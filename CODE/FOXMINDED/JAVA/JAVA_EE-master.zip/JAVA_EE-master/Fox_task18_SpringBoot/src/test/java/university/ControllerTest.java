package university;


import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.any;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;

import com.university.University;
import com.university.controller.UniversityController;
import com.university.entity.Lesson;
import com.university.entity.Student;
import com.university.entity.Teacher;
import com.university.service.LessonService;
import com.university.service.StudentService;
import com.university.service.TeacherService;

@JsonTest
@WebMvcTest(UniversityController.class)
public class ControllerTest {

    @Autowired
    private JacksonTester<Lesson> json;

    @Autowired
    private StudentService studentService;
    
    @Autowired
    private TeacherService teacherService;
    
    @Autowired
    private LessonService lessonService;
    
    @Autowired
    private MockMvc mockMvc;

    @Test
    void testSerializeLesson() throws Exception {
        Lesson lessonDB = lessonService.findById(1602);
        assertThat(this.json.write(lessonDB)).isStrictlyEqualToJson("simple-lesson.json");
    }

    @Test
    public void testStudentReturn200() throws Exception {
        Student studentTest = studentService.findById(5);
                
        given(studentService.findById(any())).willReturn(studentTest);
        mockMvc.perform(get("/teacherId=5"))
            .andExpect(status().isOk())
            .andExpect((ResultMatcher) content()
                 .contentTypeCompatibleWith(MediaType.APPLICATION_JSON));         
    }
    
    @Test
    public void testTeacherReturn200() throws Exception {
        Teacher teacherTest = teacherService.findById(5);
                
        given(teacherService.findById(any())).willReturn(teacherTest);
        mockMvc.perform(get("/teacherId=5"))
            .andExpect(status().isOk())
            .andExpect((ResultMatcher) content()
                 .contentTypeCompatibleWith(MediaType.APPLICATION_JSON));         
    }
    
    @Test
    public void testLessonReturn200() throws Exception {
        Student student1 = new Student("Ivan", "Borisov");
        Student student2 = new Student("Boris", "Johnson");
        Student student3 = new Student("Kevin", "Smith");
        Student student4 = new Student("John", "Maclein");
        List<Student> studentsGroup1 = new ArrayList<Student>();
        studentsGroup1.add(student1);
        studentsGroup1.add(student2);
        studentsGroup1.add(student3);
        studentsGroup1.add(student4);
        Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
        LocalDate day1 = LocalDate.of(2019, 2, 5);
        LocalTime time1 = LocalTime.of(9, 30);
        Lesson lessonTest = new Lesson(LocalDateTime.of(day1, time1).toString(), "Mathematical Analysis",
                studentsGroup1, teacher1, "115");
        lessonTest.setId(802);
                
        given(lessonService.findById(any())).willReturn(lessonTest);
        mockMvc.perform(get("/lessonId=802"))
            .andExpect(status().isOk())
            .andExpect(content()
                 .contentTypeCompatibleWith(MediaType.APPLICATION_JSON));         
    }    
}
