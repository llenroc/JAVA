package university;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import java.util.Optional;
import org.junit.Assert;
import org.mockito.Mockito;
import com.university.entity.Student;
import com.university.repository.StudentRepository;
import com.university.service.StudentService;

@SpringBootTest
class StudentServiceImplTest {
    private StudentService studentService;

    @MockBean
    private StudentRepository studentRepository;

    @Autowired
    public StudentServiceImplTest(StudentService studentService) {
        this.studentService = studentService;
    }

    @Test
    void testFindByBusinessKey() {
        Optional<Student> testStudent1 = Optional.of(new Student("Ivan", "Borisav"));
        Mockito.when(studentRepository.findById(802)).thenReturn(testStudent1);
        Student studentCurrent = studentService.findById(802);
        Assert.assertEquals(studentCurrent.getFirstName(), "Ivan");
    }

}
