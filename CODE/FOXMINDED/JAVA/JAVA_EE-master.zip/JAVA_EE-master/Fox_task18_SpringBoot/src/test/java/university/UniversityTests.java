package university;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.university.entity.Lesson;
import com.university.entity.Student;
import com.university.entity.Teacher;
import com.university.service.LessonService;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class UniversityTests {

    @Autowired
    private TestRestTemplate restTemplate;

    @LocalServerPort
    private int port;

    @Autowired
    private LessonService lessonService;

    private String getRootUrl() {
        return "http://localhost:" + port;
    }

    @Test
    public void testRestGetAllLessons() {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<String>(null, headers);
        ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/rest/showAllLessons", HttpMethod.GET,
                entity, String.class);
        assertNotNull(response.getBody());
    }

    @Test
    public void testRestCreateLesson() {
        Lesson lessonDB = lessonService.findById(1602);
        ResponseEntity<Lesson> postResponse = restTemplate.postForEntity(getRootUrl() + "/rest/showLesson", lessonDB,
                Lesson.class);
        assertNotNull(postResponse);
        assertNotNull(postResponse.getBody());
    }

    @Test
    public void testRestGetLessonById() {
        Lesson lessonURL = restTemplate.getForObject(getRootUrl() + "/rest/showLesson/1602", Lesson.class);
        Lesson lessonDB = lessonService.findById(1602);
        assertEquals(lessonURL, lessonDB);
    }

    @Test
    void testGetLessonById() {
        Student student1 = new Student("Ivan", "Borisov");
        Student student2 = new Student("Boris", "Johnson");
        Student student3 = new Student("Kevin", "Smith");
        Student student4 = new Student("John", "Maclein");
        List<Student> studentsGroup1 = new ArrayList<Student>();
        studentsGroup1.add(student1);
        studentsGroup1.add(student2);
        studentsGroup1.add(student3);
        studentsGroup1.add(student4);
        Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
        LocalDate day1 = LocalDate.of(2019, 2, 5);
        LocalTime time1 = LocalTime.of(9, 30);
        Lesson lessonTest = new Lesson(LocalDateTime.of(day1, time1).toString(), "Mathematical Analysis",
                studentsGroup1, teacher1, "115");
        lessonTest.setId(802);

        Lesson lessonCurrent = lessonService.findById(802);
        assertEquals(lessonTest, lessonCurrent);
    }

    public void testCheck_student() {
        Student studentInput = lessonService.findById(802).getStudents().get(2);
        Student studentTest = new Student("Alex", "Dimitrov");
        assertEquals(studentInput, studentTest);
    }

    @Test
    public void testCheck_lessonName() {
        String lessonNameInput = lessonService.findById(802).getSubject();
        String lessonNameOutput = "Mathematical Analysis";
        assertEquals(lessonNameInput, lessonNameOutput);
    }

    @Test
    public void testCheck_teacher() {
        Teacher teacherInput = lessonService.findById(802).getTeacher();
        Teacher teacherOutput = new Teacher("Valeryi", "Buldigin");
        assertEquals(teacherInput, teacherOutput);
    }

    @Test
    public void testUpdateLesson() {
        Student student1 = new Student("Ivan", "Borisov");
        Student student2 = new Student("Boris", "Johnson");
        Student student3 = new Student("Kevin", "Smith");
        Student student4 = new Student("John", "Maclein");
        List<Student> studentsGroup1 = new ArrayList<Student>();
        studentsGroup1.add(student1);
        studentsGroup1.add(student2);
        studentsGroup1.add(student3);
        studentsGroup1.add(student4);
        Teacher teacher1 = new Teacher("Valeryi", "Buldigin");
        LocalDate day1 = LocalDate.of(2019, 2, 5);
        LocalTime time1 = LocalTime.of(9, 30);
        Lesson lessonTest = new Lesson(LocalDateTime.of(day1, time1).toString(), "Subject123", studentsGroup1, teacher1,
                "115");
        lessonTest.setId(802);

        Lesson lessonDB = lessonService.findById(802);
        lessonService.update(lessonDB);
        assertEquals(lessonTest, lessonDB);
    }

}
