package com.foxminded.oleksiisaiun.task3.division;

public class FormatDivision {

	public String showResult(DataDivision data) {
		int dividendOut = Math.abs(data.getDividend());
		int divisorOut = Math.abs(data.getDivisor());
		int quotienterOut;
		String space = "";
		int[] remainderInterim = data.getDataRemainderInterim();
		int[] differenceInterim = data.getDataDifferenceInterim();
		int remainder = data.getDataRemainder();
		int quotient = data.getDataQuotient();		
		int sizeArray = remainderInterim.length;
		String output = "";
		
		for (int j = 0; j < remainderInterim.length; j++) {
			if ( j == 0) {
				quotienterOut = remainderInterim[j];
				output=space + dividendOut + "|" + divisorOut+"\n"+
				space + "-" + getSpace(outputLength(dividendOut)) + "----------"+"\n"+
				space + differenceInterim[j] + getSpace(outputLength(dividendOut)) + quotient+"\n"+
				space + "__"+"\n";
				if (sizeArray == 1) {
					output=output+space + " " + remainder;
				}

			} else if ( j > 0) {
				quotienterOut = differenceInterim[j];
				output=output+space + " " + remainderInterim[j]+"\n"+
				space + "-"+"\n"+
				space + " " + quotienterOut+"\n"+
				space + "___"+"\n";
				if (j == sizeArray - 1) {
					output=output+space + " " + remainder;
				}
				space = space + " ";
			}
		}
		return output;
	}
	
	private String getSpace(int length) {
		String output = "";
		for (int j = 0; j < length; j++) {
			output = output + " ";
		}
		return output;
	}

	private int outputLength(int value) {
		return String.valueOf(value).length();
	}

}
