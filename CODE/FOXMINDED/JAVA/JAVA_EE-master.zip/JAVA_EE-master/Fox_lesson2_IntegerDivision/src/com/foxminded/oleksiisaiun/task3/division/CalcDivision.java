package com.foxminded.oleksiisaiun.task3.division;

public class CalcDivision {
	public DataDivision divide(int inputDividend, int inputDivisor) {
		DataDivision data = new DataDivision();
		int[] remainderInterim = getRemainderInterim(inputDividend, inputDivisor);
		int[] differenceInterim = getDifferenceInterim(inputDividend, inputDivisor);
		int remainder = getRemainder(inputDividend, inputDivisor);
		int quotient = getQuotientAll(inputDividend, inputDivisor);
		
		data.setDividend(inputDividend);
		data.setDivisor(inputDivisor);
		data.setDataRemainderInterim(remainderInterim);
		data.setDataDifferenceInterim(differenceInterim);
		data.setDataRemainder(remainder);
		data.setDataQuotient(quotient); 

		return data;
	}

	private String[] parse(int input) {
		String dividend = String.valueOf(input);
		String[] arr = new String[dividend.length()];

		for (int i = 0; i < dividend.length(); i++) {
			arr[i] = Character.toString(dividend.charAt(i));
		}
		return arr;
	}

	private int defineDividendDigits(int inputDividend, int inputDivisor) {
		String[] dividend = parse(inputDividend);
		int j = 0;
		int remainder = 0;
		String output = dividend[j];

		while (j < dividend.length - 1) {
			remainder = Integer.valueOf(output) / inputDivisor;
			if (remainder > 0) {
				break;
			}
			j++;
			output = output + dividend[j];
		}
		return Integer.valueOf(output);
	}

	private String addLeadingZeros(String remainder, int divisor) {
		String output = "";
		boolean checkValue1 = Integer.valueOf(remainder) == 0;
		boolean checkValue2 = Integer.valueOf(remainder) / divisor == 0;
		
		if (checkValue1) {
			for (int j = 0; j < remainder.length() - 1; j++) {
				output = "0" + output;
			}
		} else if (checkValue2) {
			output = "0";
		}
		return output;
	}
	
	private int getQuotientIndividual(int inputDividend, int inputDivisor) {
		String[] dividend = parse(inputDividend);
		int quotientOut = 0;
		String remainderStep = "";
		String remainder;
		String step = "";

		for (int j = 0; j < dividend.length; j++) {
			step = step + dividend[j];
			int quotientStep = Integer.valueOf(step) / inputDivisor;
			remainderStep = String.valueOf(inputDividend).substring(j + 1);
			remainder = Integer.valueOf(step) - quotientStep * inputDivisor + remainderStep;

			if (quotientStep > 0 && remainderStep.length() > 0) {
				quotientOut = Integer.valueOf(quotientStep + addLeadingZeros(remainder, inputDivisor));
				break;
			} else if (quotientStep > 0) {
				quotientOut = quotientStep;
				break;
			}
		}
		return quotientOut;
	}

	private int getRestOfDividendAfterDivision(int inputDividend, int inputDivisor) {
		String[] dividend = parse(inputDividend);
		String remainderStep = "";
		String step = "";
		int output;
		int minus;

		for (int j = 0; j < dividend.length; j++) {
			step = step + dividend[j];
			remainderStep = String.valueOf(inputDividend).substring(j + 1);
			if (Integer.valueOf(step) / inputDivisor > 0) {
				break;
			}
		}

		minus = defineDividendDigits(inputDividend, inputDivisor)
				- (inputDivisor * getQuotientIndividual(inputDividend, inputDivisor));
		output = Integer.valueOf(minus + remainderStep);
		return output;
	}

	private int getQuotientAll(int inputDividend, int inputDivisor) {
		// result is a concatenation of all quotients
		String output = "";
		int j = 0;
		int rest;
		int quotientOutput;

		if (inputDividend == 0) {
			output = "0";
		} else {
			do {
				rest = getRestOfDividendAfterDivision(inputDividend, inputDivisor);
				quotientOutput = getQuotientIndividual(inputDividend, inputDivisor);
				output = output + quotientOutput;
				inputDividend = rest; // loop
				j++;
			} while (rest / inputDivisor > 0);
		}
		return Integer.valueOf(output);
	}

	private int[] getRemainderInterim(int inputDividend, int inputDivisor) {
		int[] output = new int[String.valueOf(inputDividend).length()];
		int j = 0;
		int rest;

		do {
			rest = getRestOfDividendAfterDivision(inputDividend, inputDivisor);
			output[j] = defineDividendDigits(inputDividend, inputDivisor);
			inputDividend = rest; // loop
			j++;
		} while (rest / inputDivisor > 0);
		return output;
	}

	private int[] getDifferenceInterim(int inputDividend, int inputDivisor) {
		String quotient = String.valueOf(getQuotientAll(inputDividend, inputDivisor));
		int[] output = new int[String.valueOf(inputDividend).length()];
		
		for (int j = 0; j < quotient.length(); j++) {
			output[j] = inputDivisor * Character.getNumericValue(quotient.charAt(j));
		}
		return output;
	}

	private int getRemainder(int inputDividend, int inputDivisor) {
		return inputDividend % inputDivisor;
	}
}