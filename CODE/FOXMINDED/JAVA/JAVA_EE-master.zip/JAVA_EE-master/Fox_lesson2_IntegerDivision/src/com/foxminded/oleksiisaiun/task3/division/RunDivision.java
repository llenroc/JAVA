package com.foxminded.oleksiisaiun.task3.division;

public class RunDivision {

	public static void main(String[] args) {
		int dividend = 78945; // input
		int divisor = 4; // input
		try {
			CalcDivision calc = new CalcDivision();
			DataDivision data = calc.divide(dividend, divisor);
			FormatDivision format = new FormatDivision();
			System.out.println(format.showResult(data));
		} catch (ArithmeticException e) {
			System.out.print("division_by_zero");
		}

	}

}
