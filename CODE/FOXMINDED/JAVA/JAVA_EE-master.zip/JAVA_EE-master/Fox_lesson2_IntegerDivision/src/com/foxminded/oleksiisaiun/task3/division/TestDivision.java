package com.foxminded.oleksiisaiun.task3.division;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

import org.junit.jupiter.api.Test;

public class TestDivision {
	// --------------------------------------
	// 1. Case: 2/1=2+0
	@Test
	public void testDivision_DividendDivisorEqual() {

		int inputDividend = 2;
		int inputDivisor = 1;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();		
		int checkQuotienter = 2;
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 2. Case: 140/1=140+0
	@Test
	public void testDivision_DividendEqualOne() {
		int inputDividend = 140;
		int inputDivisor = 1;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 140;
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 3. Case: 780/12=65+0
	@Test
	public void testDivision_780_div_12() {
		int inputDividend = 780;
		int inputDivisor = 12;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 65;
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 4. Case: 3000/6=500+0
	@Test
	public void testDivision_3000_div_6() {
		int inputDividend = 3000;
		int inputDivisor = 6;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 500;
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 5. Case: 1340/68=19+48/68
	@Test
	public void testDivision_1340_div_68() {
		int inputDividend = 1340;
		int inputDivisor = 68;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 19;
		int checkRemainder = 48;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 6. Case: 8642/4=2160+2/4
	@Test
	public void testDivision_8642_div_4() {
		int inputDividend = 8642;
		int inputDivisor = 4;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 2160;
		int checkRemainder = 2;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 7. Case: 12000/3=4000+0
	@Test
	public void testDivision_12000_div_3() {
		int inputDividend = 12000;
		int inputDivisor = 3;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 4000;
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 8. Case: 4152789/554=7496+5/554
	@Test
	public void testDivision_4152789_div_554() {
		int inputDividend = 4152789;
		int inputDivisor = 554;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 7496;
		int checkRemainder = 5;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 9. Case: 78945/4=19736+1/4
	@Test
	public void testDivision_78945_div_4() {
		int inputDividend = 78945;
		int inputDivisor = 4;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 19736;
		int checkRemainder = 1;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	// --------------------------------------
	// 10. Case: 0/555=0+0
	@Test
	public void testDivision_DividendZero() {
		int inputDividend = 0;
		int inputDivisor = 555;
		CalcDivision calc=new  CalcDivision();
		DataDivision data = calc.divide(inputDividend, inputDivisor);		
		
		int inputQuotienter = data.getDataQuotient();
		int inputRemainder = data.getDataRemainder();	
		int checkQuotienter = 0;
		int checkRemainder = 0;
		assertEquals(checkQuotienter, inputQuotienter);
		assertEquals(checkRemainder, inputRemainder);
	}

	
}
