package com.foxminded.oleksiisaiun.task3.division;

public class DataDivision {
	private int dividend;
	private int divisor;
	private int[] dataRemainderInterim;
	private int[] dataDifferenceInterim;
	private int dataRemainder;
	private int dataQuotient;

	public DataDivision() {
	}

	public int getDividend() {
		return dividend;
	}

	public void setDividend(int dividend) {
		this.dividend = dividend;
	}

	public int getDivisor() {
		return divisor;
	}

	public void setDivisor(int divisor) {
		this.divisor = divisor;
	}

	public int[] getDataRemainderInterim() {
		return dataRemainderInterim;
	}

	public void setDataRemainderInterim(int[] dataRemainderInterim) {
		this.dataRemainderInterim = dataRemainderInterim;
	}

	public int[] getDataDifferenceInterim() {
		return dataDifferenceInterim;
	}

	public void setDataDifferenceInterim(int[] dataDifferenceInterim) {
		this.dataDifferenceInterim = dataDifferenceInterim;
	}

	public int getDataRemainder() {
		return dataRemainder;
	}

	public void setDataRemainder(int dataRemainder) {
		this.dataRemainder = dataRemainder;
	}

	public int getDataQuotient() {
		return dataQuotient;
	}

	public void setDataQuotient(int dataQuotient) {
		this.dataQuotient = dataQuotient;
	}



}
