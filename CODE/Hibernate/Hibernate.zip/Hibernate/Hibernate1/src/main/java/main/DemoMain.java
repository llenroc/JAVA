package main;

import java.util.List;

import org.hibernate.Session;

import dao.StunentDAO;
import model.Student;
 
/**
 * Class used to perform CRUD operation on database with Hibernate API's
 * 
 */
public class DemoMain {
 
    @SuppressWarnings("unused")
    public static void main(String[] args) {
 
        StunentDAO studentDAO = new StunentDAO();

        int studentId1 = studentDAO.saveStudent("Sam", "Disilva", "Maths");
        int studentId2 = studentDAO.saveStudent("Joshua", "Brill", "Science");
        int studentId3 = studentDAO.saveStudent("Peter", "Pan", "Physics");
        int studentId4 = studentDAO.saveStudent("Bill", "Laurent", "Maths");
        
        /*
         * Retrieve all saved objects
         */
        System.out.println("**********************************************");
        System.out.println("List of all persisted students >>>");
        List<Student> students = studentDAO.getAllStudents();
        for (Student student : students) {
            System.out.println("Persisted Student :" + student);
        }


        studentDAO.updateStudent(studentId4, "ARTS");
        studentDAO.deleteStudent(studentId2);
 
        
         // Retrieve all saved objects
         
        System.out.println("**********************************************");
        System.out.println("List of students aster changes>>>");
        List<Student> remaingStudents = studentDAO.getAllStudents();
        System.out.println("List of all remained persisted students >>>");
        for (Student student : remaingStudents) {
            System.out.println("Persisted Student :" + student);
        }
 
    }
 

 

}