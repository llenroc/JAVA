package dao;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;

import entity.Category;
import entity.Stock;
import util.HibernateUtil;

public class StockCategoryDAO {
    public void insert(String stockCode, String stockName, Set<Category> categories) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

        Stock stock = new Stock();
        stock.setStockCode(stockCode);
        stock.setStockName(stockName);
        stock.setCategories(categories);
        session.save(stock);

        session.getTransaction().commit();
    }
}
