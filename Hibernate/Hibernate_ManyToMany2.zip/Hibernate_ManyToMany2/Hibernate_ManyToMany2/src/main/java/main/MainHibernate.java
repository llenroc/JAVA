package main;

import java.util.HashSet;
import java.util.Set;

import dao.StockCategoryDAO;
import entity.Category;

public class MainHibernate {

    public static void main(String[] args) {
        StockCategoryDAO stockCategoryDAO = new StockCategoryDAO();

        Category category1 = new Category("CORPORATE", "CORPORATE COMPANY");
        Category category2 = new Category("RETAIL", "RETAIL COMPANY");

        Set<Category> categories = new HashSet<Category>();
        categories.add(category1);
        categories.add(category2);

        // insert into DB
        stockCategoryDAO.insert("2345", "EPAM", categories);

    }

}
